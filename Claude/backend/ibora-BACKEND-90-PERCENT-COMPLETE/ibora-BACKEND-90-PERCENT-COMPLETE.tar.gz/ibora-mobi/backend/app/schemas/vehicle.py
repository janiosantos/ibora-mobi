"""
Vehicle schemas
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from uuid import UUID

from app.models.vehicle import VehicleStatus, VehicleType


class VehicleCreate(BaseModel):
    """Create vehicle"""
    plate: str = Field(..., min_length=7, max_length=10)
    brand: str
    model: str
    year: int = Field(..., ge=1900, le=2030)
    color: str
    type: VehicleType = VehicleType.ECONOMY
    seats: int = Field(default=4, ge=2, le=7)
    
    @staticmethod
    def validate_plate(cls, v):
        """Validate Brazilian plate format"""
        # Remove formatting
        plate = v.upper().replace('-', '').replace(' ', '')
        # Brazilian format: ABC1234 or ABC1D23
        if len(plate) != 7:
            raise ValueError('Invalid plate format')
        return plate


class VehicleUpdate(BaseModel):
    """Update vehicle"""
    brand: Optional[str] = None
    model: Optional[str] = None
    year: Optional[int] = None
    color: Optional[str] = None
    type: Optional[VehicleType] = None
    seats: Optional[int] = None
    is_default: Optional[bool] = None


class VehicleDocuments(BaseModel):
    """Upload vehicle documents"""
    renavam: Optional[str] = None
    crlv_url: Optional[str] = None


class VehiclePhotos(BaseModel):
    """Vehicle photos"""
    photos: List[str] = Field(..., max_items=10)


class VehicleResponse(BaseModel):
    """Vehicle response"""
    id: UUID
    driver_id: UUID
    plate: str
    brand: str
    model: str
    year: int
    color: str
    type: VehicleType
    status: VehicleStatus
    seats: int
    photos: List[str]
    is_default: bool
    crlv_verified: bool
    created_at: datetime
    
    class Config:
        from_attributes = True
