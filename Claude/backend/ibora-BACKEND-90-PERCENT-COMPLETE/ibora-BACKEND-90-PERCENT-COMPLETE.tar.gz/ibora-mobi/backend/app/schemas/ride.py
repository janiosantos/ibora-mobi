"""
Ride schemas (Pydantic)
"""
from pydantic import BaseModel, Field, validator
from typing import Optional, List
from datetime import datetime
from uuid import UUID

from app.models.ride import RideStatus, PaymentMethod


class Location(BaseModel):
    """Location schema"""
    lat: float = Field(..., ge=-90, le=90)
    lng: float = Field(..., ge=-180, le=180)
    address: str


class RideRequest(BaseModel):
    """Ride request from passenger"""
    pickup: Location
    dropoff: Location
    offered_price: Optional[float] = None
    payment_method: Optional[PaymentMethod] = None


class RideEstimate(BaseModel):
    """Ride price estimate"""
    distance_km: float
    duration_min: int
    base_price: float
    distance_price: float
    time_price: float
    platform_fee: float
    surge_multiplier: float
    estimated_price: float


class RideAccept(BaseModel):
    """Driver accepts ride"""
    ride_id: UUID


class RideUpdateLocation(BaseModel):
    """Update ride location (real-time tracking)"""
    lat: float = Field(..., ge=-90, le=90)
    lng: float = Field(..., ge=-180, le=180)


class RideVerifyPIN(BaseModel):
    """Verify PIN code"""
    pin_code: str = Field(..., min_length=4, max_length=4)


class RideCancel(BaseModel):
    """Cancel ride"""
    reason: str


class RideRating(BaseModel):
    """Rate ride"""
    rating: int = Field(..., ge=1, le=5)
    review: Optional[str] = None
    tags: Optional[List[str]] = []


class RideResponse(BaseModel):
    """Ride response"""
    id: UUID
    status: RideStatus
    
    # Users
    passenger_id: UUID
    driver_id: Optional[UUID]
    
    # Locations
    pickup: Location
    dropoff: Location
    
    # Distance & Duration
    estimated_distance_km: float
    estimated_duration_min: int
    actual_distance_km: Optional[float]
    actual_duration_min: Optional[int]
    
    # Pricing
    estimated_price: float
    final_price: Optional[float]
    offered_price: Optional[float]
    driver_earnings: Optional[float]
    
    # Payment
    payment_method: Optional[PaymentMethod]
    payment_status: str
    
    # PIN
    pin_code: Optional[str]
    
    # Rating
    passenger_rating: Optional[int]
    driver_rating: Optional[int]
    
    # Timestamps
    requested_at: datetime
    accepted_at: Optional[datetime]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    cancelled_at: Optional[datetime]
    
    class Config:
        from_attributes = True


class RideDetailResponse(RideResponse):
    """Ride with full details"""
    passenger: "UserResponse"
    driver: Optional["UserResponse"]
    vehicle: Optional["VehicleResponse"]
    route: Optional[List[dict]]


# Prevent circular imports
from app.schemas.user import UserResponse
from app.schemas.vehicle import VehicleResponse

RideDetailResponse.model_rebuild()
