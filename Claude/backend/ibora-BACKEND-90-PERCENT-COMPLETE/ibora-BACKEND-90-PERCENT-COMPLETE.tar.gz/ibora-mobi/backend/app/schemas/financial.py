"""
Wallet and Financial schemas
"""
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from uuid import UUID

from app.models.financial import EventType, EventStatus, WithdrawalStatus


class WalletResponse(BaseModel):
    """Wallet response"""
    id: UUID
    user_id: UUID
    
    # Balances
    available_balance: float
    pending_balance: float
    blocked_balance: float
    
    # Driver specific
    total_earnings: Optional[float]
    total_withdrawals: Optional[float]
    
    # Passenger specific
    credit_balance: Optional[float]
    
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class FinancialEventResponse(BaseModel):
    """Financial event response"""
    id: UUID
    type: EventType
    status: EventStatus
    amount: float
    balance_before: float
    balance_after: float
    description: str
    settled: bool
    settlement_date: Optional[datetime]
    created_at: datetime
    
    class Config:
        from_attributes = True


class WithdrawalRequest(BaseModel):
    """Withdrawal request"""
    amount: float = Field(..., gt=0)
    pix_key: str
    pix_key_type: str = Field(..., regex="^(cpf|email|phone|random)$")
    
    def __init__(self, **data):
        super().__init__(**data)
        # Validate amount (min R$ 50)
        if self.amount < 50.0:
            raise ValueError("Minimum withdrawal amount is R$ 50.00")


class WithdrawalResponse(BaseModel):
    """Withdrawal response"""
    id: UUID
    amount: float
    status: WithdrawalStatus
    pix_key: str
    pix_key_type: str
    fee: float
    net_amount: float
    transaction_id: Optional[str]
    requested_at: datetime
    processed_at: Optional[datetime]
    completed_at: Optional[datetime]
    
    class Config:
        from_attributes = True


class TransactionHistory(BaseModel):
    """Transaction history response"""
    events: list[FinancialEventResponse]
    total_count: int
    page: int
    page_size: int
