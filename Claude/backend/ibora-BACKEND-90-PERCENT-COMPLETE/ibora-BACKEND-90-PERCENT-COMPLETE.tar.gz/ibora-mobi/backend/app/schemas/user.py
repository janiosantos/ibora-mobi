"""
User schemas (Pydantic)
"""
from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional
from datetime import datetime
from uuid import UUID

from app.models.user import UserRole, UserStatus


# Base schemas
class UserBase(BaseModel):
    """Base user schema"""
    email: EmailStr
    phone: str
    name: str


class UserCreate(UserBase):
    """User registration schema"""
    password: str = Field(..., min_length=8)
    cpf: str = Field(..., min_length=11, max_length=14)
    role: UserRole
    birth_date: Optional[datetime] = None
    
    @validator('cpf')
    def validate_cpf(cls, v):
        """Validate CPF format"""
        # Remove formatting
        cpf = ''.join(filter(str.isdigit, v))
        if len(cpf) != 11:
            raise ValueError('CPF must have 11 digits')
        return cpf
    
    @validator('phone')
    def validate_phone(cls, v):
        """Validate phone format"""
        # Remove formatting
        phone = ''.join(filter(str.isdigit, v))
        if len(phone) < 10 or len(phone) > 11:
            raise ValueError('Phone must have 10 or 11 digits')
        return phone


class UserUpdate(BaseModel):
    """User update schema"""
    name: Optional[str] = None
    avatar_url: Optional[str] = None
    birth_date: Optional[datetime] = None


class UserLogin(BaseModel):
    """Login schema"""
    email: EmailStr
    password: str


class UserResponse(UserBase):
    """User response schema"""
    id: UUID
    role: UserRole
    status: UserStatus
    cpf: str
    avatar_url: Optional[str]
    birth_date: Optional[datetime]
    rating: float
    total_rides: int
    
    # Driver specific
    driver_license: Optional[str] = None
    driver_license_verified: bool = False
    online: Optional[bool] = None
    
    # Verification
    email_verified: bool
    phone_verified: bool
    cpf_verified: bool
    
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class DriverLocationUpdate(BaseModel):
    """Driver location update"""
    lat: float = Field(..., ge=-90, le=90)
    lng: float = Field(..., ge=-180, le=180)


class DriverOnlineStatus(BaseModel):
    """Driver online status"""
    online: bool


# Token schemas
class Token(BaseModel):
    """JWT Token"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    """Token payload"""
    user_id: str
    role: UserRole
