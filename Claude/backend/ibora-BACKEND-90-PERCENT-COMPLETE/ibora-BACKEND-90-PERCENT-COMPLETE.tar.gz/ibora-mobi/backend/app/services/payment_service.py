"""
Payment Service - PIX and Card processing
"""
from typing import Optional, Dict, Any
from uuid import UUID
import httpx
import stripe
from datetime import datetime, timedelta

from app.core.config import settings
from app.models.ride import Ride, PaymentMethod
from app.models.financial import FinancialEvent, EventType, EventStatus

# Initialize Stripe
stripe.api_key = settings.STRIPE_SECRET_KEY


class PaymentService:
    """Payment processing service"""
    
    @staticmethod
    async def create_pix_charge(
        ride: Ride,
        amount: float
    ) -> Dict[str, Any]:
        """
        Create PIX charge via Efí Pay (Gerencianet)
        
        Returns:
            {
                "txid": str,
                "qrcode": str (base64 image),
                "qrcode_text": str (copy-paste),
                "expiration": datetime
            }
        """
        # Efí Pay API configuration
        efi_url = "https://api.gerencianet.com.br/v1" if not settings.EFI_SANDBOX else "https://api-pix-h.gerencianet.com.br/v2"
        
        # Get OAuth token
        async with httpx.AsyncClient() as client:
            # 1. Get access token
            auth_response = await client.post(
                f"{efi_url}/oauth/token",
                auth=(settings.EFI_CLIENT_ID, settings.EFI_CLIENT_SECRET),
                data={"grant_type": "client_credentials"}
            )
            
            if auth_response.status_code != 200:
                raise Exception("Failed to authenticate with Efí Pay")
            
            access_token = auth_response.json()["access_token"]
            
            # 2. Create PIX charge
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json"
            }
            
            # Generate txid (transaction ID)
            import uuid
            txid = str(uuid.uuid4()).replace('-', '')[:35]
            
            # Create charge
            charge_data = {
                "calendario": {
                    "expiracao": 3600  # 1 hour
                },
                "devedor": {
                    "cpf": ride.passenger.cpf if ride.passenger else "00000000000",
                    "nome": ride.passenger.name if ride.passenger else "Passenger"
                },
                "valor": {
                    "original": f"{amount:.2f}"
                },
                "chave": settings.EFI_PIX_KEY,
                "solicitacaoPagador": f"Ride {ride.id}"
            }
            
            charge_response = await client.put(
                f"{efi_url}/cob/{txid}",
                headers=headers,
                json=charge_data
            )
            
            if charge_response.status_code not in [200, 201]:
                raise Exception(f"Failed to create PIX charge: {charge_response.text}")
            
            charge_result = charge_response.json()
            
            # 3. Get QR Code
            loc_id = charge_result.get("loc", {}).get("id")
            
            qrcode_response = await client.get(
                f"{efi_url}/loc/{loc_id}/qrcode",
                headers=headers
            )
            
            if qrcode_response.status_code != 200:
                raise Exception("Failed to get QR Code")
            
            qrcode_data = qrcode_response.json()
            
            return {
                "txid": txid,
                "qrcode": qrcode_data.get("imagemQrcode"),  # base64
                "qrcode_text": qrcode_data.get("qrcode"),  # copy-paste
                "expiration": datetime.utcnow() + timedelta(hours=1),
                "status": "PENDING"
            }
    
    @staticmethod
    async def check_pix_status(txid: str) -> str:
        """
        Check PIX payment status
        
        Returns: PENDING | PAID | EXPIRED | CANCELLED
        """
        efi_url = "https://api.gerencianet.com.br/v1" if not settings.EFI_SANDBOX else "https://api-pix-h.gerencianet.com.br/v2"
        
        async with httpx.AsyncClient() as client:
            # Get token
            auth_response = await client.post(
                f"{efi_url}/oauth/token",
                auth=(settings.EFI_CLIENT_ID, settings.EFI_CLIENT_SECRET),
                data={"grant_type": "client_credentials"}
            )
            
            access_token = auth_response.json()["access_token"]
            
            # Check status
            headers = {"Authorization": f"Bearer {access_token}"}
            
            status_response = await client.get(
                f"{efi_url}/cob/{txid}",
                headers=headers
            )
            
            if status_response.status_code != 200:
                return "PENDING"
            
            result = status_response.json()
            status = result.get("status")
            
            # Map Efí status to our status
            status_map = {
                "ATIVA": "PENDING",
                "CONCLUIDA": "PAID",
                "REMOVIDA_PELO_USUARIO_RECEBEDOR": "CANCELLED",
                "REMOVIDA_PELO_PSP": "CANCELLED"
            }
            
            return status_map.get(status, "PENDING")
    
    @staticmethod
    async def create_card_payment(
        ride: Ride,
        amount: float,
        payment_method_id: Optional[str] = None,
        card_token: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create card payment via Stripe
        
        Args:
            payment_method_id: Saved card ID
            card_token: New card token
        
        Returns:
            {
                "payment_intent_id": str,
                "client_secret": str,
                "status": str
            }
        """
        try:
            # Create or retrieve customer
            customer_id = None
            if ride.passenger:
                # Check if customer exists in metadata
                if hasattr(ride.passenger, 'metadata') and ride.passenger.metadata:
                    customer_id = ride.passenger.metadata.get('stripe_customer_id')
                
                # Create customer if doesn't exist
                if not customer_id:
                    customer = stripe.Customer.create(
                        email=ride.passenger.email,
                        name=ride.passenger.name,
                        metadata={'user_id': str(ride.passenger.id)}
                    )
                    customer_id = customer.id
                    
                    # Save to user metadata
                    if not ride.passenger.metadata:
                        ride.passenger.metadata = {}
                    ride.passenger.metadata['stripe_customer_id'] = customer_id
            
            # Create payment intent
            payment_intent = stripe.PaymentIntent.create(
                amount=int(amount * 100),  # Convert to cents
                currency='brl',
                customer=customer_id,
                payment_method=payment_method_id,
                confirmation_method='automatic',
                confirm=True if payment_method_id else False,
                metadata={
                    'ride_id': str(ride.id),
                    'passenger_id': str(ride.passenger_id)
                }
            )
            
            return {
                "payment_intent_id": payment_intent.id,
                "client_secret": payment_intent.client_secret,
                "status": payment_intent.status,
                "amount": amount
            }
            
        except stripe.error.StripeError as e:
            raise Exception(f"Stripe error: {str(e)}")
    
    @staticmethod
    async def save_payment_method(
        user_id: UUID,
        payment_method_id: str
    ) -> Dict[str, Any]:
        """
        Save payment method (card) for future use
        """
        try:
            # Get payment method details
            payment_method = stripe.PaymentMethod.retrieve(payment_method_id)
            
            return {
                "id": payment_method.id,
                "type": payment_method.type,
                "card": {
                    "brand": payment_method.card.brand,
                    "last4": payment_method.card.last4,
                    "exp_month": payment_method.card.exp_month,
                    "exp_year": payment_method.card.exp_year
                }
            }
            
        except stripe.error.StripeError as e:
            raise Exception(f"Failed to save payment method: {str(e)}")
    
    @staticmethod
    def process_webhook(
        payload: Dict[str, Any],
        signature: str,
        webhook_type: str = "stripe"
    ) -> Dict[str, Any]:
        """
        Process payment webhooks (Stripe or Efí)
        """
        if webhook_type == "stripe":
            try:
                event = stripe.Webhook.construct_event(
                    payload,
                    signature,
                    settings.STRIPE_WEBHOOK_SECRET
                )
                
                if event.type == 'payment_intent.succeeded':
                    payment_intent = event.data.object
                    return {
                        "success": True,
                        "type": "payment_succeeded",
                        "payment_id": payment_intent.id,
                        "ride_id": payment_intent.metadata.get('ride_id'),
                        "amount": payment_intent.amount / 100
                    }
                
                elif event.type == 'payment_intent.payment_failed':
                    payment_intent = event.data.object
                    return {
                        "success": False,
                        "type": "payment_failed",
                        "payment_id": payment_intent.id,
                        "ride_id": payment_intent.metadata.get('ride_id'),
                        "error": payment_intent.last_payment_error
                    }
                
            except Exception as e:
                raise Exception(f"Webhook error: {str(e)}")
        
        elif webhook_type == "efi":
            # Efí Pay webhook processing
            pix = payload.get("pix", [{}])[0]
            txid = pix.get("txid")
            status = pix.get("status")
            
            return {
                "success": status == "CONCLUIDA",
                "type": "pix_payment",
                "txid": txid,
                "status": status,
                "amount": float(pix.get("valor", 0))
            }
        
        return {"success": False, "error": "Unknown webhook type"}
