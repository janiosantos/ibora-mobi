"""
Wallet Service - Ledger and Settlement
"""
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import Optional, List
from uuid import UUID
from datetime import datetime, timedelta
from decimal import Decimal

from app.models.financial import (
    Wallet,
    FinancialEvent,
    EventType,
    EventStatus,
    Withdrawal,
    WithdrawalStatus
)
from app.models.ride import Ride
from app.core.config import settings


class WalletService:
    """Wallet and financial operations"""
    
    @staticmethod
    async def get_or_create_wallet(
        db: AsyncSession,
        user_id: UUID,
        wallet_type: str
    ) -> Wallet:
        """Get or create wallet for user"""
        result = await db.execute(
            select(Wallet).where(Wallet.user_id == user_id)
        )
        wallet = result.scalar_one_or_none()
        
        if not wallet:
            wallet = Wallet(
                user_id=user_id,
                type=wallet_type
            )
            db.add(wallet)
            await db.commit()
            await db.refresh(wallet)
        
        return wallet
    
    @staticmethod
    async def create_financial_event(
        db: AsyncSession,
        wallet: Wallet,
        event_type: EventType,
        amount: float,
        description: str,
        ride_id: Optional[UUID] = None,
        payment_id: Optional[str] = None,
        idempotency_key: Optional[str] = None
    ) -> FinancialEvent:
        """
        Create financial event (append-only ledger)
        
        This is the ONLY way to modify wallet balance
        """
        # Check idempotency
        if idempotency_key:
            result = await db.execute(
                select(FinancialEvent).where(
                    FinancialEvent.idempotency_key == idempotency_key
                )
            )
            existing = result.scalar_one_or_none()
            if existing:
                return existing
        
        # Calculate settlement date (D+N)
        settlement_date = None
        if event_type in [EventType.RIDE_EARNING, EventType.INCENTIVE_BONUS]:
            settlement_date = datetime.utcnow() + timedelta(days=settings.SETTLEMENT_DAYS)
        
        # Record balance before
        balance_before = wallet.available_balance
        
        # Determine which balance to update
        if event_type in [EventType.RIDE_EARNING, EventType.INCENTIVE_BONUS]:
            # Goes to pending first
            wallet.pending_balance += amount
        elif event_type == EventType.WITHDRAWAL:
            # Deduct from available
            wallet.available_balance -= abs(amount)
            wallet.total_withdrawals += abs(amount)
        elif event_type == EventType.PLATFORM_COMMISSION:
            # Deduct from pending
            wallet.pending_balance -= abs(amount)
        else:
            # Direct to available
            wallet.available_balance += amount
        
        # Calculate balance after
        balance_after = wallet.available_balance
        
        # Create event
        event = FinancialEvent(
            wallet_id=wallet.id,
            type=event_type,
            status=EventStatus.COMPLETED,
            amount=amount,
            balance_before=balance_before,
            balance_after=balance_after,
            ride_id=ride_id,
            payment_id=payment_id,
            settlement_date=settlement_date,
            settled=False if settlement_date else True,
            description=description,
            idempotency_key=idempotency_key
        )
        
        db.add(event)
        await db.commit()
        await db.refresh(event)
        
        return event
    
    @staticmethod
    async def process_ride_payment(
        db: AsyncSession,
        ride: Ride,
        payment_id: str
    ) -> None:
        """
        Process ride payment and create financial events
        
        Flow:
        1. Passenger pays (already done via PIX/Card)
        2. Create RIDE_EARNING for driver (pending)
        3. Create PLATFORM_COMMISSION (deduct from pending)
        """
        # Get driver wallet
        driver_wallet = await WalletService.get_or_create_wallet(
            db, ride.driver_id, "driver"
        )
        
        # 1. Driver earning (goes to pending, D+N settlement)
        await WalletService.create_financial_event(
            db=db,
            wallet=driver_wallet,
            event_type=EventType.RIDE_EARNING,
            amount=ride.driver_earnings,
            description=f"Ride {ride.id} earning",
            ride_id=ride.id,
            payment_id=payment_id,
            idempotency_key=f"ride_earning_{ride.id}"
        )
        
        # 2. Platform commission
        await WalletService.create_financial_event(
            db=db,
            wallet=driver_wallet,
            event_type=EventType.PLATFORM_COMMISSION,
            amount=-ride.platform_commission,  # Negative = debit
            description=f"Platform commission for ride {ride.id}",
            ride_id=ride.id,
            idempotency_key=f"platform_commission_{ride.id}"
        )
        
        # Update driver total earnings
        driver_wallet.total_earnings += ride.driver_earnings
        
        await db.commit()
    
    @staticmethod
    async def settle_pending_events(
        db: AsyncSession
    ) -> int:
        """
        Settlement job (D+N)
        
        Moves pending balance to available after settlement date
        
        This should run daily via Celery
        """
        # Get events ready for settlement
        now = datetime.utcnow()
        
        result = await db.execute(
            select(FinancialEvent).where(
                and_(
                    FinancialEvent.settled == False,
                    FinancialEvent.settlement_date <= now
                )
            )
        )
        events = result.scalars().all()
        
        settled_count = 0
        
        for event in events:
            # Get wallet
            result = await db.execute(
                select(Wallet).where(Wallet.id == event.wallet_id)
            )
            wallet = result.scalar_one()
            
            # Move from pending to available
            wallet.pending_balance -= event.amount
            wallet.available_balance += event.amount
            
            # Mark as settled
            event.settled = True
            event.processed_at = now
            
            settled_count += 1
        
        await db.commit()
        
        return settled_count
    
    @staticmethod
    async def create_withdrawal(
        db: AsyncSession,
        wallet: Wallet,
        amount: float,
        pix_key: str,
        pix_key_type: str
    ) -> Withdrawal:
        """
        Create withdrawal request
        """
        # Validate amount
        if amount < settings.MIN_WITHDRAWAL_AMOUNT:
            raise ValueError(f"Minimum withdrawal is R$ {settings.MIN_WITHDRAWAL_AMOUNT}")
        
        if amount > wallet.available_balance:
            raise ValueError("Insufficient balance")
        
        # Calculate fee (example: R$ 2.00 per withdrawal)
        fee = 2.00
        net_amount = amount - fee
        
        # Create withdrawal
        withdrawal = Withdrawal(
            wallet_id=wallet.id,
            amount=amount,
            pix_key=pix_key,
            pix_key_type=pix_key_type,
            fee=fee,
            net_amount=net_amount,
            status=WithdrawalStatus.PENDING
        )
        
        db.add(withdrawal)
        await db.flush()
        
        # Create financial event (deduct from available)
        await WalletService.create_financial_event(
            db=db,
            wallet=wallet,
            event_type=EventType.WITHDRAWAL,
            amount=-amount,
            description=f"Withdrawal via PIX ({pix_key})",
            payment_id=str(withdrawal.id),
            idempotency_key=f"withdrawal_{withdrawal.id}"
        )
        
        await db.commit()
        await db.refresh(withdrawal)
        
        # TODO: Process PIX transfer via Efí Pay API
        # For now, auto-approve
        withdrawal.status = WithdrawalStatus.COMPLETED
        withdrawal.completed_at = datetime.utcnow()
        await db.commit()
        
        return withdrawal
    
    @staticmethod
    async def get_transaction_history(
        db: AsyncSession,
        wallet: Wallet,
        limit: int = 50,
        offset: int = 0
    ) -> List[FinancialEvent]:
        """Get wallet transaction history"""
        result = await db.execute(
            select(FinancialEvent)
            .where(FinancialEvent.wallet_id == wallet.id)
            .order_by(FinancialEvent.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        
        return result.scalars().all()
