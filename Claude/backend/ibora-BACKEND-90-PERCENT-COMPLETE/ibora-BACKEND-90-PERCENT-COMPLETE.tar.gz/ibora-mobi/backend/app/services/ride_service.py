"""
Ride Service - Business Logic
"""
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_
from typing import Optional, List
from uuid import UUID
from datetime import datetime
import random
import string

from app.models.ride import Ride, RideStatus, PaymentMethod
from app.models.user import User, UserRole
from app.models.vehicle import Vehicle
from app.schemas.ride import RideRequest, RideEstimate
from app.core.config import settings


class RideService:
    """Ride business logic"""
    
    @staticmethod
    def calculate_distance(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
        """
        Calculate distance in km using Haversine formula
        """
        from math import radians, sin, cos, sqrt, atan2
        
        R = 6371  # Earth radius in km
        
        lat1, lng1, lat2, lng2 = map(radians, [lat1, lng1, lat2, lng2])
        dlat = lat2 - lat1
        dlng = lng2 - lng1
        
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlng/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        
        return R * c
    
    @staticmethod
    def calculate_price(distance_km: float, duration_min: int) -> RideEstimate:
        """
        Calculate ride price
        
        Formula:
        - Base price: R$ 5.00
        - Distance: R$ 2.50/km
        - Time: R$ 0.50/min
        - Platform fee: 20% of total
        - Surge: 1.0x (normal), can be 1.5x, 2.0x in peak hours
        """
        base_price = 5.00
        distance_price = distance_km * 2.50
        time_price = duration_min * 0.50
        
        subtotal = base_price + distance_price + time_price
        platform_fee = subtotal * settings.PLATFORM_COMMISSION_RATE
        
        # Simple surge logic (can be enhanced with real-time data)
        surge_multiplier = 1.0
        hour = datetime.now().hour
        if hour in [7, 8, 9, 17, 18, 19]:  # Peak hours
            surge_multiplier = 1.5
        
        estimated_price = (subtotal + platform_fee) * surge_multiplier
        
        return RideEstimate(
            distance_km=round(distance_km, 2),
            duration_min=duration_min,
            base_price=round(base_price, 2),
            distance_price=round(distance_price, 2),
            time_price=round(time_price, 2),
            platform_fee=round(platform_fee, 2),
            surge_multiplier=surge_multiplier,
            estimated_price=round(estimated_price, 2)
        )
    
    @staticmethod
    def generate_pin() -> str:
        """Generate 4-digit PIN code"""
        return ''.join(random.choices(string.digits, k=4))
    
    @staticmethod
    async def create_ride(
        db: AsyncSession,
        passenger: User,
        ride_data: RideRequest
    ) -> Ride:
        """
        Create new ride request
        """
        # Calculate distance
        distance_km = RideService.calculate_distance(
            ride_data.pickup.lat,
            ride_data.pickup.lng,
            ride_data.dropoff.lat,
            ride_data.dropoff.lng
        )
        
        # Estimate duration (simple: 2 min/km + 5 min base)
        duration_min = int(distance_km * 2 + 5)
        
        # Calculate price
        estimate = RideService.calculate_price(distance_km, duration_min)
        
        # Create ride
        ride = Ride(
            passenger_id=passenger.id,
            status=RideStatus.REQUESTING,
            pickup_lat=ride_data.pickup.lat,
            pickup_lng=ride_data.pickup.lng,
            pickup_address=ride_data.pickup.address,
            dropoff_lat=ride_data.dropoff.lat,
            dropoff_lng=ride_data.dropoff.lng,
            dropoff_address=ride_data.dropoff.address,
            estimated_distance_km=estimate.distance_km,
            estimated_duration_min=estimate.duration_min,
            base_price=estimate.base_price,
            distance_price=estimate.distance_price,
            time_price=estimate.time_price,
            platform_fee=estimate.platform_fee,
            surge_multiplier=estimate.surge_multiplier,
            estimated_price=estimate.estimated_price,
            offered_price=ride_data.offered_price or estimate.estimated_price,
            payment_method=ride_data.payment_method,
            pin_code=RideService.generate_pin()
        )
        
        db.add(ride)
        await db.commit()
        await db.refresh(ride)
        
        return ride
    
    @staticmethod
    async def find_available_drivers(
        db: AsyncSession,
        pickup_lat: float,
        pickup_lng: float,
        radius_km: float = 5.0
    ) -> List[User]:
        """
        Find available drivers near pickup location
        
        Note: In production, use PostGIS for efficient geo queries
        For now, we'll do a simple filter
        """
        # Get online drivers
        result = await db.execute(
            select(User).where(
                and_(
                    User.role == UserRole.DRIVER,
                    User.online == True,
                    User.status == "active"
                )
            )
        )
        drivers = result.scalars().all()
        
        # Filter by distance (simple implementation)
        available_drivers = []
        for driver in drivers:
            if driver.last_lat and driver.last_lng:
                distance = RideService.calculate_distance(
                    pickup_lat,
                    pickup_lng,
                    driver.last_lat,
                    driver.last_lng
                )
                if distance <= radius_km:
                    available_drivers.append(driver)
        
        return available_drivers
    
    @staticmethod
    async def accept_ride(
        db: AsyncSession,
        ride: Ride,
        driver: User,
        vehicle: Optional[Vehicle] = None
    ) -> Ride:
        """
        Driver accepts ride
        """
        if ride.status != RideStatus.REQUESTING:
            raise ValueError("Ride is not available for acceptance")
        
        # Get driver's default vehicle if not provided
        if not vehicle:
            result = await db.execute(
                select(Vehicle).where(
                    and_(
                        Vehicle.driver_id == driver.id,
                        Vehicle.is_default == True
                    )
                )
            )
            vehicle = result.scalar_one_or_none()
            
            if not vehicle:
                raise ValueError("Driver has no vehicle")
        
        # Update ride
        ride.driver_id = driver.id
        ride.vehicle_id = vehicle.id
        ride.status = RideStatus.DRIVER_ASSIGNED
        ride.accepted_at = datetime.utcnow()
        
        # Calculate driver earnings (price - platform commission)
        ride.driver_earnings = ride.estimated_price * (1 - settings.PLATFORM_COMMISSION_RATE)
        ride.platform_commission = ride.estimated_price * settings.PLATFORM_COMMISSION_RATE
        
        await db.commit()
        await db.refresh(ride)
        
        return ride
    
    @staticmethod
    async def update_ride_status(
        db: AsyncSession,
        ride: Ride,
        new_status: RideStatus
    ) -> Ride:
        """
        Update ride status (state machine transitions)
        """
        valid_transitions = {
            RideStatus.REQUESTING: [RideStatus.DRIVER_ASSIGNED, RideStatus.CANCELLED],
            RideStatus.DRIVER_ASSIGNED: [RideStatus.DRIVER_ARRIVING, RideStatus.CANCELLED_BY_DRIVER],
            RideStatus.DRIVER_ARRIVING: [RideStatus.ARRIVED, RideStatus.CANCELLED_BY_DRIVER],
            RideStatus.ARRIVED: [RideStatus.IN_PROGRESS, RideStatus.CANCELLED_BY_DRIVER],
            RideStatus.IN_PROGRESS: [RideStatus.COMPLETED],
        }
        
        if new_status not in valid_transitions.get(ride.status, []):
            raise ValueError(f"Invalid transition from {ride.status} to {new_status}")
        
        # Update status
        ride.status = new_status
        
        # Update timestamps
        now = datetime.utcnow()
        if new_status == RideStatus.ARRIVED:
            ride.arrived_at = now
        elif new_status == RideStatus.IN_PROGRESS:
            ride.started_at = now
        elif new_status == RideStatus.COMPLETED:
            ride.completed_at = now
            # Calculate actual duration
            if ride.started_at:
                duration = (now - ride.started_at).total_seconds() / 60
                ride.actual_duration_min = int(duration)
        elif new_status in [RideStatus.CANCELLED, RideStatus.CANCELLED_BY_DRIVER, RideStatus.CANCELLED_BY_PASSENGER]:
            ride.cancelled_at = now
        
        await db.commit()
        await db.refresh(ride)
        
        return ride
    
    @staticmethod
    async def cancel_ride(
        db: AsyncSession,
        ride: Ride,
        cancelled_by: User,
        reason: str
    ) -> Ride:
        """
        Cancel ride with fee logic
        """
        # Determine cancellation status
        if cancelled_by.role == UserRole.DRIVER:
            new_status = RideStatus.CANCELLED_BY_DRIVER
        else:
            new_status = RideStatus.CANCELLED_BY_PASSENGER
        
        ride.status = new_status
        ride.cancelled_by = cancelled_by.id
        ride.cancellation_reason = reason
        ride.cancelled_at = datetime.utcnow()
        
        # Apply cancellation fee
        if cancelled_by.role == UserRole.DRIVER and ride.status in [RideStatus.DRIVER_ASSIGNED, RideStatus.DRIVER_ARRIVING]:
            ride.cancellation_fee = settings.DRIVER_CANCELLATION_FEE
        elif cancelled_by.role == UserRole.PASSENGER and ride.status == RideStatus.ARRIVED:
            ride.cancellation_fee = settings.PASSENGER_CANCELLATION_FEE
        
        await db.commit()
        await db.refresh(ride)
        
        return ride
