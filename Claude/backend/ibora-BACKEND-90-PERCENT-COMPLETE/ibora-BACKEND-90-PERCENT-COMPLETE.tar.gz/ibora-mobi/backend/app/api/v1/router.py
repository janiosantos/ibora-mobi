"""
API v1 Router - Main router
"""
from fastapi import APIRouter

from app.api.v1.endpoints import auth, rides

api_router = APIRouter()

# Include routers
api_router.include_router(auth.router, prefix="/auth", tags=["Authentication"])
api_router.include_router(rides.router, prefix="/rides", tags=["Rides"])

# TODO: Add more routers
# api_router.include_router(users.router, prefix="/users", tags=["Users"])
# api_router.include_router(payments.router, prefix="/payments", tags=["Payments"])
# api_router.include_router(wallets.router, prefix="/wallet", tags=["Wallet"])
# api_router.include_router(vehicles.router, prefix="/vehicles", tags=["Vehicles"])
