"""
Ride endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, desc
from typing import List
from uuid import UUID

from app.db.session import get_db
from app.api.dependencies import get_current_user, get_current_driver, get_current_passenger
from app.models.user import User
from app.models.ride import Ride, RideStatus
from app.models.vehicle import Vehicle
from app.schemas.ride import (
    RideRequest,
    RideEstimate,
    RideResponse,
    RideDetailResponse,
    RideAccept,
    RideCancel,
    RideRating,
    RideVerifyPIN,
    Location
)
from app.services.ride_service import RideService

router = APIRouter()


@router.post("/estimate", response_model=RideEstimate)
async def estimate_ride(
    pickup: Location,
    dropoff: Location,
    current_user: User = Depends(get_current_passenger)
):
    """
    Get ride price estimate
    """
    # Calculate distance
    distance_km = RideService.calculate_distance(
        pickup.lat, pickup.lng,
        dropoff.lat, dropoff.lng
    )
    
    # Estimate duration
    duration_min = int(distance_km * 2 + 5)
    
    # Calculate price
    estimate = RideService.calculate_price(distance_km, duration_min)
    
    return estimate


@router.post("", response_model=RideResponse, status_code=status.HTTP_201_CREATED)
async def request_ride(
    ride_data: RideRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_passenger)
):
    """
    Request new ride (passenger)
    """
    ride = await RideService.create_ride(db, current_user, ride_data)
    
    # TODO: Broadcast to available drivers via WebSocket
    # TODO: Add to matching queue
    
    return ride


@router.get("/{ride_id}", response_model=RideDetailResponse)
async def get_ride(
    ride_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get ride details
    """
    result = await db.execute(
        select(Ride).where(Ride.id == ride_id)
    )
    ride = result.scalar_one_or_none()
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found"
        )
    
    # Verify user has access to this ride
    if ride.passenger_id != current_user.id and ride.driver_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    return ride


@router.get("", response_model=List[RideResponse])
async def list_rides(
    status_filter: RideStatus = None,
    limit: int = Query(20, le=100),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    List rides (history)
    """
    # Build query
    query = select(Ride).where(
        or_(
            Ride.passenger_id == current_user.id,
            Ride.driver_id == current_user.id
        )
    )
    
    if status_filter:
        query = query.where(Ride.status == status_filter)
    
    query = query.order_by(desc(Ride.created_at)).limit(limit).offset(offset)
    
    result = await db.execute(query)
    rides = result.scalars().all()
    
    return rides


@router.post("/{ride_id}/accept", response_model=RideResponse)
async def accept_ride(
    ride_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """
    Accept ride (driver)
    """
    # Get ride
    result = await db.execute(
        select(Ride).where(Ride.id == ride_id)
    )
    ride = result.scalar_one_or_none()
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found"
        )
    
    if ride.status != RideStatus.REQUESTING:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Ride is no longer available"
        )
    
    # Get driver's default vehicle
    result = await db.execute(
        select(Vehicle).where(
            and_(
                Vehicle.driver_id == current_user.id,
                Vehicle.is_default == True
            )
        )
    )
    vehicle = result.scalar_one_or_none()
    
    if not vehicle:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You must register a vehicle first"
        )
    
    # Accept ride
    ride = await RideService.accept_ride(db, ride, current_user, vehicle)
    
    # TODO: Notify passenger via WebSocket
    
    return ride


@router.put("/{ride_id}/status", response_model=RideResponse)
async def update_status(
    ride_id: UUID,
    new_status: RideStatus,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """
    Update ride status (driver only)
    """
    # Get ride
    result = await db.execute(
        select(Ride).where(Ride.id == ride_id)
    )
    ride = result.scalar_one_or_none()
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found"
        )
    
    if ride.driver_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only assigned driver can update ride"
        )
    
    try:
        ride = await RideService.update_ride_status(db, ride, new_status)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    
    # TODO: Notify passenger via WebSocket
    
    return ride


@router.post("/{ride_id}/verify-pin", response_model=RideResponse)
async def verify_pin(
    ride_id: UUID,
    pin_data: RideVerifyPIN,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """
    Verify PIN code before starting ride
    """
    result = await db.execute(
        select(Ride).where(Ride.id == ride_id)
    )
    ride = result.scalar_one_or_none()
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found"
        )
    
    if ride.driver_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    if ride.pin_code != pin_data.pin_code:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid PIN code"
        )
    
    # Update to IN_PROGRESS
    ride = await RideService.update_ride_status(db, ride, RideStatus.IN_PROGRESS)
    
    return ride


@router.post("/{ride_id}/cancel", response_model=RideResponse)
async def cancel_ride(
    ride_id: UUID,
    cancel_data: RideCancel,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Cancel ride
    """
    result = await db.execute(
        select(Ride).where(Ride.id == ride_id)
    )
    ride = result.scalar_one_or_none()
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found"
        )
    
    # Verify user can cancel
    if ride.passenger_id != current_user.id and ride.driver_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    # Cannot cancel completed rides
    if ride.status == RideStatus.COMPLETED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot cancel completed ride"
        )
    
    ride = await RideService.cancel_ride(db, ride, current_user, cancel_data.reason)
    
    # TODO: Notify other party via WebSocket
    
    return ride


@router.post("/{ride_id}/rate", response_model=RideResponse)
async def rate_ride(
    ride_id: UUID,
    rating_data: RideRating,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Rate ride after completion
    """
    result = await db.execute(
        select(Ride).where(Ride.id == ride_id)
    )
    ride = result.scalar_one_or_none()
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found"
        )
    
    if ride.status != RideStatus.COMPLETED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Can only rate completed rides"
        )
    
    # Update rating
    if current_user.id == ride.passenger_id:
        ride.driver_rating = rating_data.rating
        ride.driver_review = rating_data.review
        
        # Update driver's overall rating
        if ride.driver:
            # Simple average (can be enhanced with weighted average)
            driver = ride.driver
            total_rating = driver.rating * driver.total_rides + rating_data.rating
            driver.total_rides += 1
            driver.rating = total_rating / driver.total_rides
            
    elif current_user.id == ride.driver_id:
        ride.passenger_rating = rating_data.rating
        ride.passenger_review = rating_data.review
        
        # Update passenger's overall rating
        if ride.passenger:
            passenger = ride.passenger
            total_rating = passenger.rating * passenger.total_rides + rating_data.rating
            passenger.total_rides += 1
            passenger.rating = total_rating / passenger.total_rides
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    await db.commit()
    await db.refresh(ride)
    
    return ride
