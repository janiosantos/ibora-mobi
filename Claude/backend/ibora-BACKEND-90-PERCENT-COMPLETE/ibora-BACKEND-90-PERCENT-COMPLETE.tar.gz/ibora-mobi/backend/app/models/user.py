"""
User model
"""
from sqlalchemy import Column, String, Boolean, DateTime, Enum, Float, Integer
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid
import enum

from app.db.session import Base


class UserRole(str, enum.Enum):
    """User roles"""
    PASSENGER = "passenger"
    DRIVER = "driver"
    ADMIN = "admin"


class UserStatus(str, enum.Enum):
    """User status"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    PENDING_VERIFICATION = "pending_verification"


class User(Base):
    """User model"""
    __tablename__ = "users"

    # Primary Key
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # Basic Info
    email = Column(String(255), unique=True, nullable=False, index=True)
    phone = Column(String(20), unique=True, nullable=False, index=True)
    cpf = Column(String(14), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    
    # Profile
    name = Column(String(255), nullable=False)
    avatar_url = Column(String(512), nullable=True)
    birth_date = Column(DateTime, nullable=True)
    
    # Role & Status
    role = Column(Enum(UserRole), nullable=False)
    status = Column(
        Enum(UserStatus), 
        nullable=False, 
        default=UserStatus.PENDING_VERIFICATION
    )
    
    # Verification
    email_verified = Column(Boolean, default=False)
    phone_verified = Column(Boolean, default=False)
    cpf_verified = Column(Boolean, default=False)
    
    # Rating (denormalized for performance)
    rating = Column(Float, default=5.0)
    total_rides = Column(Integer, default=0)
    
    # Driver specific (null for passengers)
    driver_license = Column(String(20), nullable=True)
    driver_license_verified = Column(Boolean, default=False)
    online = Column(Boolean, default=False)  # Driver online status
    
    # Location (for matching)
    last_lat = Column(Float, nullable=True)
    last_lng = Column(Float, nullable=True)
    last_location_update = Column(DateTime, nullable=True)
    
    # Metadata
    metadata = Column(JSONB, nullable=True, default={})
    
    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(
        DateTime, 
        nullable=False, 
        default=datetime.utcnow, 
        onupdate=datetime.utcnow
    )
    deleted_at = Column(DateTime, nullable=True)
    
    # Relationships
    rides_as_passenger = relationship(
        "Ride", 
        back_populates="passenger",
        foreign_keys="Ride.passenger_id"
    )
    rides_as_driver = relationship(
        "Ride", 
        back_populates="driver",
        foreign_keys="Ride.driver_id"
    )
    vehicles = relationship("Vehicle", back_populates="driver")
    wallet = relationship("Wallet", back_populates="user", uselist=False)
    
    def __repr__(self):
        return f"<User {self.email}>"
