"""
Vehicle model
"""
from sqlalchemy import Column, String, Integer, DateTime, Enum, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid
import enum

from app.db.session import Base


class VehicleStatus(str, enum.Enum):
    """Vehicle status"""
    PENDING_VERIFICATION = "pending_verification"
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"


class VehicleType(str, enum.Enum):
    """Vehicle types"""
    ECONOMY = "economy"
    COMFORT = "comfort"
    PREMIUM = "premium"


class Vehicle(Base):
    """Vehicle model"""
    __tablename__ = "vehicles"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    driver_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    
    # Vehicle info
    plate = Column(String(10), unique=True, nullable=False, index=True)
    brand = Column(String(100), nullable=False)
    model = Column(String(100), nullable=False)
    year = Column(Integer, nullable=False)
    color = Column(String(50), nullable=False)
    
    # Type
    type = Column(Enum(VehicleType), nullable=False, default=VehicleType.ECONOMY)
    status = Column(Enum(VehicleStatus), nullable=False, default=VehicleStatus.PENDING_VERIFICATION)
    
    # Documents
    renavam = Column(String(20), nullable=True)
    crlv_url = Column(String(512), nullable=True)  # Vehicle registration document
    crlv_verified = Column(Boolean, default=False)
    
    # Photos
    photos = Column(JSONB, nullable=True, default=[])  # Array of photo URLs
    
    # Capacity
    seats = Column(Integer, default=4)
    
    # Default vehicle for driver
    is_default = Column(Boolean, default=False)
    
    # Metadata
    metadata = Column(JSONB, nullable=True, default={})
    
    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    deleted_at = Column(DateTime, nullable=True)
    
    # Relationships
    driver = relationship("User", back_populates="vehicles")
    rides = relationship("Ride", back_populates="vehicle")
    
    def __repr__(self):
        return f"<Vehicle {self.plate}>"
