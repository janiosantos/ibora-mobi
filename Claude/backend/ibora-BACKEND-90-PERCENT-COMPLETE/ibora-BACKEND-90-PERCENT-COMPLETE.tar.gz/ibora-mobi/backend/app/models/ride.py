"""
Ride model - Core business entity
"""
from sqlalchemy import Column, String, Float, DateTime, Enum, Integer, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid
import enum

from app.db.session import Base


class RideStatus(str, enum.Enum):
    """Ride status flow"""
    REQUESTING = "requesting"  # Passenger requesting
    DRIVER_ASSIGNED = "driver_assigned"  # Driver accepted
    DRIVER_ARRIVING = "driver_arriving"  # Driver going to pickup
    ARRIVED = "arrived"  # Driver arrived at pickup
    IN_PROGRESS = "in_progress"  # Trip started
    COMPLETED = "completed"  # Trip finished
    CANCELLED = "cancelled"  # Cancelled
    CANCELLED_BY_DRIVER = "cancelled_by_driver"
    CANCELLED_BY_PASSENGER = "cancelled_by_passenger"


class PaymentMethod(str, enum.Enum):
    """Payment methods"""
    CASH = "cash"
    PIX = "pix"
    CARD = "card"
    WALLET = "wallet"


class Ride(Base):
    """Ride model - State machine"""
    __tablename__ = "rides"

    # Primary Key
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # Users
    passenger_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    driver_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Status
    status = Column(Enum(RideStatus), nullable=False, default=RideStatus.REQUESTING)
    
    # Locations
    pickup_lat = Column(Float, nullable=False)
    pickup_lng = Column(Float, nullable=False)
    pickup_address = Column(String(512), nullable=False)
    
    dropoff_lat = Column(Float, nullable=False)
    dropoff_lng = Column(Float, nullable=False)
    dropoff_address = Column(String(512), nullable=False)
    
    # Distance & Duration (estimated vs actual)
    estimated_distance_km = Column(Float, nullable=False)
    estimated_duration_min = Column(Integer, nullable=False)
    actual_distance_km = Column(Float, nullable=True)
    actual_duration_min = Column(Integer, nullable=True)
    
    # Pricing
    base_price = Column(Float, nullable=False)
    distance_price = Column(Float, nullable=False)
    time_price = Column(Float, nullable=False)
    platform_fee = Column(Float, nullable=False)
    surge_multiplier = Column(Float, default=1.0)
    
    offered_price = Column(Float, nullable=True)  # Passenger offer
    estimated_price = Column(Float, nullable=False)
    final_price = Column(Float, nullable=True)
    
    # Driver earnings
    driver_earnings = Column(Float, nullable=True)
    platform_commission = Column(Float, nullable=True)
    
    # Payment
    payment_method = Column(Enum(PaymentMethod), nullable=True)
    payment_status = Column(String(50), default="pending")  # pending, paid, failed
    payment_id = Column(String(255), nullable=True)  # External payment ID
    
    # Vehicle
    vehicle_id = Column(UUID(as_uuid=True), ForeignKey("vehicles.id"), nullable=True)
    
    # PIN code for verification
    pin_code = Column(String(4), nullable=True)
    
    # Rating
    passenger_rating = Column(Integer, nullable=True)  # 1-5
    driver_rating = Column(Integer, nullable=True)  # 1-5
    passenger_review = Column(Text, nullable=True)
    driver_review = Column(Text, nullable=True)
    
    # Cancellation
    cancelled_by = Column(UUID(as_uuid=True), nullable=True)
    cancellation_reason = Column(String(512), nullable=True)
    cancellation_fee = Column(Float, default=0.0)
    
    # Route (array of coordinates)
    route = Column(JSONB, nullable=True)
    
    # Metadata
    metadata = Column(JSONB, nullable=True, default={})
    
    # Timestamps
    requested_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    accepted_at = Column(DateTime, nullable=True)
    arrived_at = Column(DateTime, nullable=True)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    cancelled_at = Column(DateTime, nullable=True)
    
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(
        DateTime, 
        nullable=False, 
        default=datetime.utcnow, 
        onupdate=datetime.utcnow
    )
    
    # Relationships
    passenger = relationship("User", foreign_keys=[passenger_id], back_populates="rides_as_passenger")
    driver = relationship("User", foreign_keys=[driver_id], back_populates="rides_as_driver")
    vehicle = relationship("Vehicle", back_populates="rides")
    financial_events = relationship("FinancialEvent", back_populates="ride")
    
    def __repr__(self):
        return f"<Ride {self.id} {self.status}>"
    
    @property
    def duration_minutes(self) -> int:
        """Calculate actual duration in minutes"""
        if self.started_at and self.completed_at:
            delta = self.completed_at - self.started_at
            return int(delta.total_seconds() / 60)
        return 0
