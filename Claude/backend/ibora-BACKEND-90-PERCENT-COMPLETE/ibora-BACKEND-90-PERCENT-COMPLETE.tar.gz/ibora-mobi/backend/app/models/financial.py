"""
Financial models - Wallet and Ledger
"""
from sqlalchemy import Column, String, Float, DateTime, Enum, ForeignKey, Boolean, Integer
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid
import enum

from app.db.session import Base


class WalletType(str, enum.Enum):
    """Wallet types"""
    DRIVER = "driver"
    PASSENGER = "passenger"


class WalletStatus(str, enum.Enum):
    """Wallet status"""
    ACTIVE = "active"
    SUSPENDED = "suspended"
    BLOCKED = "blocked"


class Wallet(Base):
    """
    Wallet model - Driver's financial account
    Passenger wallet for credits/vouchers
    """
    __tablename__ = "wallets"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, unique=True)
    
    type = Column(Enum(WalletType), nullable=False)
    status = Column(Enum(WalletStatus), nullable=False, default=WalletStatus.ACTIVE)
    
    # Balances (in cents to avoid float precision issues, but stored as float)
    available_balance = Column(Float, default=0.0)  # Available for withdrawal
    pending_balance = Column(Float, default=0.0)  # In D+N settlement
    blocked_balance = Column(Float, default=0.0)  # Blocked (disputes, etc)
    
    # Driver specific
    total_earnings = Column(Float, default=0.0)  # Lifetime earnings
    total_withdrawals = Column(Float, default=0.0)  # Lifetime withdrawals
    
    # Passenger specific
    credit_balance = Column(Float, default=0.0)  # Promotional credits
    
    # Metadata
    metadata = Column(JSONB, nullable=True, default={})
    
    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="wallet")
    financial_events = relationship("FinancialEvent", back_populates="wallet")
    
    def __repr__(self):
        return f"<Wallet {self.user_id} balance={self.available_balance}>"


class EventType(str, enum.Enum):
    """Financial event types"""
    # Income
    RIDE_EARNING = "ride_earning"
    INCENTIVE_BONUS = "incentive_bonus"
    REFERRAL_BONUS = "referral_bonus"
    
    # Outflow
    PLATFORM_COMMISSION = "platform_commission"
    WITHDRAWAL = "withdrawal"
    CANCELLATION_FEE = "cancellation_fee"
    
    # Passenger
    RIDE_PAYMENT = "ride_payment"
    CREDIT_ADDED = "credit_added"
    CREDIT_USED = "credit_used"
    
    # Adjustments
    ADJUSTMENT = "adjustment"
    REFUND = "refund"
    CHARGEBACK = "chargeback"


class EventStatus(str, enum.Enum):
    """Event status"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class FinancialEvent(Base):
    """
    Financial Event - Append-only ledger
    Every financial transaction creates an immutable event
    """
    __tablename__ = "financial_events"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    wallet_id = Column(UUID(as_uuid=True), ForeignKey("wallets.id"), nullable=False)
    
    # Event details
    type = Column(Enum(EventType), nullable=False)
    status = Column(Enum(EventStatus), nullable=False, default=EventStatus.PENDING)
    
    # Amount (positive = credit, negative = debit)
    amount = Column(Float, nullable=False)
    
    # Balances before/after (for audit)
    balance_before = Column(Float, nullable=False)
    balance_after = Column(Float, nullable=False)
    
    # Related entities
    ride_id = Column(UUID(as_uuid=True), ForeignKey("rides.id"), nullable=True)
    payment_id = Column(String(255), nullable=True)  # External payment ID
    
    # Settlement
    settlement_date = Column(DateTime, nullable=True)  # D+N date
    settled = Column(Boolean, default=False)
    
    # Description
    description = Column(String(512), nullable=False)
    
    # Metadata
    metadata = Column(JSONB, nullable=True, default={})
    
    # Idempotency
    idempotency_key = Column(String(255), unique=True, nullable=True, index=True)
    
    # Timestamps
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    processed_at = Column(DateTime, nullable=True)
    
    # Relationships
    wallet = relationship("Wallet", back_populates="financial_events")
    ride = relationship("Ride", back_populates="financial_events")
    
    def __repr__(self):
        return f"<FinancialEvent {self.type} {self.amount}>"


class WithdrawalStatus(str, enum.Enum):
    """Withdrawal status"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Withdrawal(Base):
    """
    Withdrawal request
    """
    __tablename__ = "withdrawals"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    wallet_id = Column(UUID(as_uuid=True), ForeignKey("wallets.id"), nullable=False)
    
    amount = Column(Float, nullable=False)
    status = Column(Enum(WithdrawalStatus), nullable=False, default=WithdrawalStatus.PENDING)
    
    # PIX details
    pix_key = Column(String(255), nullable=False)
    pix_key_type = Column(String(50), nullable=False)  # cpf, email, phone, random
    
    # Processing
    transaction_id = Column(String(255), nullable=True, unique=True)
    fee = Column(Float, default=0.0)
    net_amount = Column(Float, nullable=False)  # amount - fee
    
    # Metadata
    metadata = Column(JSONB, nullable=True, default={})
    
    # Timestamps
    requested_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    processed_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    
    # Relationship
    financial_event = relationship("FinancialEvent", uselist=False)
    
    def __repr__(self):
        return f"<Withdrawal {self.id} {self.status}>"
