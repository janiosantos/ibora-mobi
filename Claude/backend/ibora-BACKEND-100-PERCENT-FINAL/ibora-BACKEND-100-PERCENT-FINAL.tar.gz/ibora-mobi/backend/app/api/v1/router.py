"""
API v1 Router - Complete with all endpoints
"""
from fastapi import APIRouter

from app.api.v1.endpoints import auth, rides, payments, wallet
from app.api.v1.endpoints.users_vehicles import user_router, vehicle_router

api_router = APIRouter()

# Authentication
api_router.include_router(
    auth.router,
    prefix="/auth",
    tags=["Authentication"]
)

# Rides
api_router.include_router(
    rides.router,
    prefix="/rides",
    tags=["Rides"]
)

# Payments
api_router.include_router(
    payments.router,
    prefix="/payments",
    tags=["Payments"]
)

# Wallet
api_router.include_router(
    wallet.router,
    prefix="/wallet",
    tags=["Wallet"]
)

# Users
api_router.include_router(
    user_router,
    prefix="/users",
    tags=["Users"]
)

# Vehicles
api_router.include_router(
    vehicle_router,
    prefix="/vehicles",
    tags=["Vehicles"]
)
