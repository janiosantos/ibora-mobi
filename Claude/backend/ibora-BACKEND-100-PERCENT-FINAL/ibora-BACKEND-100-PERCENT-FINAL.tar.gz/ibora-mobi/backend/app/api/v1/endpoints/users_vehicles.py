"""
User and Vehicle endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import List
from uuid import UUID

from app.db.session import get_db
from app.api.dependencies import get_current_user, get_current_driver
from app.models.user import User
from app.models.vehicle import Vehicle
from app.schemas.user import UserResponse, UserUpdate, DriverLocationUpdate, DriverOnlineStatus
from app.schemas.vehicle import VehicleCreate, VehicleUpdate, VehicleResponse

# ==================== USER ENDPOINTS ====================

user_router = APIRouter()


@user_router.get("/me", response_model=UserResponse)
async def get_current_user_profile(
    current_user: User = Depends(get_current_user)
):
    """Get current user profile"""
    return current_user


@user_router.put("/me", response_model=UserResponse)
async def update_profile(
    user_data: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Update user profile"""
    # Update fields
    if user_data.name:
        current_user.name = user_data.name
    if user_data.avatar_url:
        current_user.avatar_url = user_data.avatar_url
    if user_data.birth_date:
        current_user.birth_date = user_data.birth_date
    
    await db.commit()
    await db.refresh(current_user)
    
    return current_user


@user_router.post("/me/location")
async def update_location(
    location: DriverLocationUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """Update driver location (for matching)"""
    from datetime import datetime
    
    current_user.last_lat = location.lat
    current_user.last_lng = location.lng
    current_user.last_location_update = datetime.utcnow()
    
    await db.commit()
    
    return {
        "status": "success",
        "lat": location.lat,
        "lng": location.lng
    }


@user_router.put("/me/online")
async def toggle_online(
    online_data: DriverOnlineStatus,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """Toggle driver online status"""
    current_user.online = online_data.online
    
    await db.commit()
    
    return {
        "status": "success",
        "online": current_user.online
    }


# ==================== VEHICLE ENDPOINTS ====================

vehicle_router = APIRouter()


@vehicle_router.post("", response_model=VehicleResponse, status_code=status.HTTP_201_CREATED)
async def create_vehicle(
    vehicle_data: VehicleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """Register new vehicle"""
    # Check if plate already exists
    result = await db.execute(
        select(Vehicle).where(Vehicle.plate == vehicle_data.plate)
    )
    if result.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Vehicle with this plate already exists"
        )
    
    # Check if this is first vehicle
    result = await db.execute(
        select(Vehicle).where(Vehicle.driver_id == current_user.id)
    )
    existing_vehicles = result.scalars().all()
    is_first = len(existing_vehicles) == 0
    
    # Create vehicle
    vehicle = Vehicle(
        driver_id=current_user.id,
        plate=vehicle_data.plate.upper(),
        brand=vehicle_data.brand,
        model=vehicle_data.model,
        year=vehicle_data.year,
        color=vehicle_data.color,
        type=vehicle_data.type,
        seats=vehicle_data.seats,
        is_default=is_first  # First vehicle is default
    )
    
    db.add(vehicle)
    await db.commit()
    await db.refresh(vehicle)
    
    return vehicle


@vehicle_router.get("", response_model=List[VehicleResponse])
async def list_vehicles(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """List driver's vehicles"""
    result = await db.execute(
        select(Vehicle).where(
            and_(
                Vehicle.driver_id == current_user.id,
                Vehicle.deleted_at.is_(None)
            )
        )
    )
    vehicles = result.scalars().all()
    
    return vehicles


@vehicle_router.get("/{vehicle_id}", response_model=VehicleResponse)
async def get_vehicle(
    vehicle_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """Get vehicle details"""
    result = await db.execute(
        select(Vehicle).where(Vehicle.id == vehicle_id)
    )
    vehicle = result.scalar_one_or_none()
    
    if not vehicle:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vehicle not found"
        )
    
    if vehicle.driver_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    return vehicle


@vehicle_router.put("/{vehicle_id}", response_model=VehicleResponse)
async def update_vehicle(
    vehicle_id: UUID,
    vehicle_data: VehicleUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """Update vehicle"""
    result = await db.execute(
        select(Vehicle).where(Vehicle.id == vehicle_id)
    )
    vehicle = result.scalar_one_or_none()
    
    if not vehicle:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vehicle not found"
        )
    
    if vehicle.driver_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    # Update fields
    if vehicle_data.brand:
        vehicle.brand = vehicle_data.brand
    if vehicle_data.model:
        vehicle.model = vehicle_data.model
    if vehicle_data.year:
        vehicle.year = vehicle_data.year
    if vehicle_data.color:
        vehicle.color = vehicle_data.color
    if vehicle_data.type:
        vehicle.type = vehicle_data.type
    if vehicle_data.seats:
        vehicle.seats = vehicle_data.seats
    if vehicle_data.is_default is not None:
        # If setting as default, unset others
        if vehicle_data.is_default:
            await db.execute(
                select(Vehicle).where(
                    and_(
                        Vehicle.driver_id == current_user.id,
                        Vehicle.id != vehicle_id
                    )
                )
            )
            other_vehicles = result.scalars().all()
            for v in other_vehicles:
                v.is_default = False
        
        vehicle.is_default = vehicle_data.is_default
    
    await db.commit()
    await db.refresh(vehicle)
    
    return vehicle


@vehicle_router.delete("/{vehicle_id}")
async def delete_vehicle(
    vehicle_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """Soft delete vehicle"""
    from datetime import datetime
    
    result = await db.execute(
        select(Vehicle).where(Vehicle.id == vehicle_id)
    )
    vehicle = result.scalar_one_or_none()
    
    if not vehicle:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Vehicle not found"
        )
    
    if vehicle.driver_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    # Soft delete
    vehicle.deleted_at = datetime.utcnow()
    
    await db.commit()
    
    return {"status": "success", "message": "Vehicle deleted"}
