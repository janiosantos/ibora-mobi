"""
Payment endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status, Header, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional
from uuid import UUID

from app.db.session import get_db
from app.api.dependencies import get_current_user, get_current_passenger
from app.models.user import User
from app.models.ride import Ride, RideStatus
from app.services.payment_service import PaymentService
from app.services.wallet_service import WalletService

router = APIRouter()


@router.post("/pix")
async def create_pix_payment(
    ride_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_passenger)
):
    """
    Create PIX payment for ride
    """
    # Get ride
    result = await db.execute(
        select(Ride).where(Ride.id == ride_id)
    )
    ride = result.scalar_one_or_none()
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found"
        )
    
    # Verify passenger
    if ride.passenger_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    # Verify ride is completed
    if ride.status != RideStatus.COMPLETED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Can only pay for completed rides"
        )
    
    # Create PIX charge
    try:
        charge = await PaymentService.create_pix_charge(
            ride=ride,
            amount=ride.final_price
        )
        
        # Update ride
        ride.payment_id = charge["txid"]
        ride.payment_status = "pending"
        ride.payment_method = "pix"
        
        await db.commit()
        
        return {
            "txid": charge["txid"],
            "qrcode": charge["qrcode"],
            "qrcode_text": charge["qrcode_text"],
            "expiration": charge["expiration"],
            "amount": ride.final_price
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create PIX payment: {str(e)}"
        )


@router.post("/card")
async def create_card_payment(
    ride_id: UUID,
    payment_method_id: Optional[str] = None,
    save_card: bool = False,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_passenger)
):
    """
    Create card payment for ride
    """
    # Get ride
    result = await db.execute(
        select(Ride).where(Ride.id == ride_id)
    )
    ride = result.scalar_one_or_none()
    
    if not ride:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ride not found"
        )
    
    # Verify passenger
    if ride.passenger_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    # Verify ride is completed
    if ride.status != RideStatus.COMPLETED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Can only pay for completed rides"
        )
    
    try:
        # Create payment
        payment = await PaymentService.create_card_payment(
            ride=ride,
            amount=ride.final_price,
            payment_method_id=payment_method_id
        )
        
        # Update ride
        ride.payment_id = payment["payment_intent_id"]
        ride.payment_status = payment["status"]
        ride.payment_method = "card"
        
        await db.commit()
        
        return {
            "payment_intent_id": payment["payment_intent_id"],
            "client_secret": payment["client_secret"],
            "status": payment["status"],
            "amount": ride.final_price
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create card payment: {str(e)}"
        )


@router.post("/webhook/stripe")
async def stripe_webhook(
    request: Request,
    stripe_signature: str = Header(None, alias="stripe-signature"),
    db: AsyncSession = Depends(get_db)
):
    """
    Stripe payment webhook
    """
    try:
        payload = await request.body()
        
        # Process webhook
        result = PaymentService.process_webhook(
            payload=payload,
            signature=stripe_signature,
            webhook_type="stripe"
        )
        
        if result.get("success"):
            # Get ride
            ride_id = result.get("ride_id")
            if ride_id:
                ride_result = await db.execute(
                    select(Ride).where(Ride.id == UUID(ride_id))
                )
                ride = ride_result.scalar_one_or_none()
                
                if ride:
                    # Update payment status
                    ride.payment_status = "paid"
                    
                    # Process wallet events
                    await WalletService.process_ride_payment(
                        db=db,
                        ride=ride,
                        payment_id=result.get("payment_id")
                    )
                    
                    await db.commit()
        
        return {"status": "success"}
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post("/webhook/efi")
async def efi_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    """
    Efí Pay (PIX) webhook
    """
    try:
        payload = await request.json()
        
        # Process webhook
        result = PaymentService.process_webhook(
            payload=payload,
            signature="",  # Efí doesn't use signature
            webhook_type="efi"
        )
        
        if result.get("success"):
            # Find ride by txid
            txid = result.get("txid")
            ride_result = await db.execute(
                select(Ride).where(Ride.payment_id == txid)
            )
            ride = ride_result.scalar_one_or_none()
            
            if ride:
                # Update payment status
                ride.payment_status = "paid"
                
                # Process wallet events
                await WalletService.process_ride_payment(
                    db=db,
                    ride=ride,
                    payment_id=txid
                )
                
                await db.commit()
        
        return {"status": "success"}
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/pix/{txid}/status")
async def check_pix_status(
    txid: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Check PIX payment status
    """
    try:
        status = await PaymentService.check_pix_status(txid)
        
        return {
            "txid": txid,
            "status": status
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )
