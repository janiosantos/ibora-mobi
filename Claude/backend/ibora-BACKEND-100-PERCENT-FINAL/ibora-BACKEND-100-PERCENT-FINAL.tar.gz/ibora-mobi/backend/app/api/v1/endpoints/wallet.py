"""
Wallet endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from app.db.session import get_db
from app.api.dependencies import get_current_driver
from app.models.user import User
from app.schemas.financial import (
    WalletResponse,
    FinancialEventResponse,
    WithdrawalRequest,
    WithdrawalResponse,
    TransactionHistory
)
from app.services.wallet_service import WalletService

router = APIRouter()


@router.get("", response_model=WalletResponse)
async def get_wallet(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """
    Get driver wallet balance
    """
    wallet = await WalletService.get_or_create_wallet(
        db=db,
        user_id=current_user.id,
        wallet_type="driver"
    )
    
    return wallet


@router.get("/transactions", response_model=TransactionHistory)
async def get_transactions(
    limit: int = Query(50, le=100),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """
    Get transaction history
    """
    # Get wallet
    wallet = await WalletService.get_or_create_wallet(
        db=db,
        user_id=current_user.id,
        wallet_type="driver"
    )
    
    # Get transactions
    events = await WalletService.get_transaction_history(
        db=db,
        wallet=wallet,
        limit=limit,
        offset=offset
    )
    
    # Get total count
    from sqlalchemy import select, func
    from app.models.financial import FinancialEvent
    
    count_result = await db.execute(
        select(func.count(FinancialEvent.id)).where(
            FinancialEvent.wallet_id == wallet.id
        )
    )
    total_count = count_result.scalar()
    
    return {
        "events": events,
        "total_count": total_count,
        "page": offset // limit + 1,
        "page_size": limit
    }


@router.post("/withdraw", response_model=WithdrawalResponse)
async def withdraw(
    withdrawal_data: WithdrawalRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """
    Request withdrawal via PIX
    """
    # Get wallet
    wallet = await WalletService.get_or_create_wallet(
        db=db,
        user_id=current_user.id,
        wallet_type="driver"
    )
    
    try:
        # Create withdrawal
        withdrawal = await WalletService.create_withdrawal(
            db=db,
            wallet=wallet,
            amount=withdrawal_data.amount,
            pix_key=withdrawal_data.pix_key,
            pix_key_type=withdrawal_data.pix_key_type
        )
        
        return withdrawal
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Withdrawal failed: {str(e)}"
        )


@router.get("/balance")
async def get_balance(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_driver)
):
    """
    Get wallet balance summary
    """
    wallet = await WalletService.get_or_create_wallet(
        db=db,
        user_id=current_user.id,
        wallet_type="driver"
    )
    
    return {
        "available": wallet.available_balance,
        "pending": wallet.pending_balance,
        "blocked": wallet.blocked_balance,
        "total_earnings": wallet.total_earnings,
        "total_withdrawals": wallet.total_withdrawals,
        "net_earnings": wallet.total_earnings - wallet.total_withdrawals
    }
