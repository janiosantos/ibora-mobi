#!/bin/bash

# iBora - Environment Check Script
# Verifica se o ambiente está configurado corretamente para Node 22

echo "🔍 iBora - Environment Check"
echo "=============================="
echo ""

# Check Node version
echo "📦 Checking Node.js version..."
NODE_VERSION=$(node --version)
NODE_MAJOR=$(echo $NODE_VERSION | cut -d'.' -f1 | sed 's/v//')

if [ "$NODE_MAJOR" -ge "22" ]; then
    echo "✅ Node.js: $NODE_VERSION (OK)"
else
    echo "❌ Node.js: $NODE_VERSION (Required: >= 22.0.0)"
    echo "   Install Node 22: nvm install 22"
    exit 1
fi

# Check npm version
echo ""
echo "📦 Checking npm version..."
NPM_VERSION=$(npm --version)
NPM_MAJOR=$(echo $NPM_VERSION | cut -d'.' -f1)

if [ "$NPM_MAJOR" -ge "10" ]; then
    echo "✅ npm: $NPM_VERSION (OK)"
else
    echo "⚠️  npm: $NPM_VERSION (Recommended: >= 10.0.0)"
    echo "   Update: npm install -g npm@latest"
fi

# Check Expo CLI
echo ""
echo "📦 Checking Expo CLI..."
if command -v expo &> /dev/null; then
    EXPO_VERSION=$(expo --version)
    echo "✅ Expo CLI: $EXPO_VERSION (OK)"
else
    echo "❌ Expo CLI not found"
    echo "   Install: npm install -g expo-cli"
    exit 1
fi

# Check if node_modules exists
echo ""
echo "📁 Checking dependencies..."
if [ -d "node_modules" ]; then
    echo "✅ node_modules exists"
else
    echo "⚠️  node_modules not found"
    echo "   Run: npm install"
fi

# Check package.json
echo ""
echo "📄 Checking package.json..."
if [ -f "package.json" ]; then
    EXPO_SDK=$(grep -o '"expo": "[^"]*"' package.json | cut -d'"' -f4)
    REACT_VERSION=$(grep -o '"react": "[^"]*"' package.json | cut -d'"' -f4)
    RN_VERSION=$(grep -o '"react-native": "[^"]*"' package.json | cut -d'"' -f4)
    
    echo "✅ Expo SDK: $EXPO_SDK"
    echo "✅ React: $REACT_VERSION"
    echo "✅ React Native: $RN_VERSION"
else
    echo "❌ package.json not found"
    exit 1
fi

# Check for common issues
echo ""
echo "🔧 Checking for common issues..."

if [ -f "package-lock.json" ]; then
    echo "✅ package-lock.json exists"
else
    echo "⚠️  package-lock.json not found (will be created on npm install)"
fi

if [ -d ".expo" ]; then
    echo "✅ .expo directory exists"
else
    echo "⚠️  .expo directory not found (will be created on expo start)"
fi

# Summary
echo ""
echo "=============================="
echo "✅ Environment check complete!"
echo ""
echo "Next steps:"
echo "1. npm install          # Install dependencies"
echo "2. npm start            # Start development server"
echo "3. npm run android      # Run on Android"
echo "4. npm run ios          # Run on iOS"
echo ""
echo "For migration guide, see: MIGRATION_NODE22.md"
echo "=============================="
