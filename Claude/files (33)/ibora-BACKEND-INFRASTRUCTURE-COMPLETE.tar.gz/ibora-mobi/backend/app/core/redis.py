"""
Redis Client with Distributed Locks
"""
import redis
from redis.lock import Lock
from typing import Optional, Any
import json
from contextlib import contextmanager
from app.core.config import settings

# Redis client (sync for Celery)
redis_client = redis.Redis(
    host=settings.REDIS_HOST,
    port=settings.REDIS_PORT,
    db=settings.REDIS_DB,
    password=settings.REDIS_PASSWORD,
    decode_responses=True,
    socket_connect_timeout=5,
    socket_keepalive=True,
    health_check_interval=30,
)

# Redis client for async operations
import redis.asyncio as aioredis

async_redis_client: Optional[aioredis.Redis] = None


async def get_redis() -> aioredis.Redis:
    """Get async Redis client"""
    global async_redis_client
    if async_redis_client is None:
        async_redis_client = await aioredis.from_url(
            f"redis://{settings.REDIS_HOST}:{settings.REDIS_PORT}/{settings.REDIS_DB}",
            password=settings.REDIS_PASSWORD,
            encoding="utf-8",
            decode_responses=True,
        )
    return async_redis_client


async def close_redis():
    """Close Redis connection"""
    global async_redis_client
    if async_redis_client:
        await async_redis_client.close()
        async_redis_client = None


class RedisLock:
    """
    Distributed lock using Redis
    
    Usage:
        with RedisLock("ride:123:accept"):
            # Only one worker can execute this
            process_ride_acceptance()
    """
    
    def __init__(
        self,
        key: str,
        timeout: int = 10,
        blocking: bool = True,
        blocking_timeout: Optional[int] = 5,
    ):
        self.lock = redis_client.lock(
            f"lock:{key}",
            timeout=timeout,
            blocking=blocking,
            blocking_timeout=blocking_timeout,
        )
    
    def __enter__(self):
        acquired = self.lock.acquire()
        if not acquired:
            raise Exception("Failed to acquire lock")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            self.lock.release()
        except Exception:
            pass  # Lock may have expired


@contextmanager
def distributed_lock(key: str, timeout: int = 10):
    """
    Context manager for distributed locks
    
    Usage:
        with distributed_lock("ride:123"):
            # Critical section
            pass
    """
    lock = RedisLock(key, timeout=timeout)
    try:
        lock.__enter__()
        yield
    finally:
        lock.__exit__(None, None, None)


class RedisCache:
    """Redis cache helper"""
    
    @staticmethod
    def get(key: str) -> Optional[Any]:
        """Get value from cache"""
        value = redis_client.get(key)
        if value:
            try:
                return json.loads(value)
            except:
                return value
        return None
    
    @staticmethod
    def set(key: str, value: Any, ttl: int = 3600):
        """Set value in cache"""
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
        redis_client.setex(key, ttl, value)
    
    @staticmethod
    def delete(key: str):
        """Delete key from cache"""
        redis_client.delete(key)
    
    @staticmethod
    def exists(key: str) -> bool:
        """Check if key exists"""
        return redis_client.exists(key) > 0
    
    @staticmethod
    def increment(key: str, amount: int = 1) -> int:
        """Increment counter"""
        return redis_client.incrby(key, amount)
    
    @staticmethod
    def expire(key: str, ttl: int):
        """Set expiration"""
        redis_client.expire(key, ttl)
    
    @staticmethod
    def get_pattern(pattern: str) -> list:
        """Get all keys matching pattern"""
        return redis_client.keys(pattern)
    
    @staticmethod
    def delete_pattern(pattern: str):
        """Delete all keys matching pattern"""
        keys = redis_client.keys(pattern)
        if keys:
            redis_client.delete(*keys)


class RateLimiter:
    """
    Rate limiter using Redis
    
    Usage:
        limiter = RateLimiter("user:123:api", limit=100, window=60)
        if limiter.is_allowed():
            # Process request
            pass
    """
    
    def __init__(self, key: str, limit: int, window: int):
        self.key = f"ratelimit:{key}"
        self.limit = limit
        self.window = window
    
    def is_allowed(self) -> bool:
        """Check if request is allowed"""
        current = redis_client.get(self.key)
        
        if current is None:
            # First request in window
            redis_client.setex(self.key, self.window, 1)
            return True
        
        if int(current) >= self.limit:
            return False
        
        redis_client.incr(self.key)
        return True
    
    def get_remaining(self) -> int:
        """Get remaining requests"""
        current = redis_client.get(self.key)
        if current is None:
            return self.limit
        return max(0, self.limit - int(current))
    
    def reset(self):
        """Reset counter"""
        redis_client.delete(self.key)


class IdempotencyCache:
    """
    Idempotency cache using Redis
    
    Usage:
        cache = IdempotencyCache()
        if cache.is_processed("payment:123"):
            return cached_response
        
        result = process_payment()
        cache.mark_processed("payment:123", result)
    """
    
    @staticmethod
    def is_processed(key: str) -> bool:
        """Check if already processed"""
        return redis_client.exists(f"idempotent:{key}") > 0
    
    @staticmethod
    def mark_processed(key: str, result: Any = None, ttl: int = 86400):
        """Mark as processed (default 24h TTL)"""
        value = json.dumps(result) if result else "1"
        redis_client.setex(f"idempotent:{key}", ttl, value)
    
    @staticmethod
    def get_result(key: str) -> Optional[Any]:
        """Get cached result"""
        value = redis_client.get(f"idempotent:{key}")
        if value and value != "1":
            try:
                return json.loads(value)
            except:
                pass
        return None


# Convenience functions
def cache_driver_location(driver_id: str, lat: float, lng: float, ttl: int = 300):
    """Cache driver location (5 min TTL)"""
    RedisCache.set(
        f"driver:{driver_id}:location",
        {"lat": lat, "lng": lng},
        ttl=ttl
    )


def get_driver_location(driver_id: str) -> Optional[dict]:
    """Get cached driver location"""
    return RedisCache.get(f"driver:{driver_id}:location")


def cache_ride(ride_id: str, ride_data: dict, ttl: int = 3600):
    """Cache ride data"""
    RedisCache.set(f"ride:{ride_id}", ride_data, ttl=ttl)


def get_cached_ride(ride_id: str) -> Optional[dict]:
    """Get cached ride"""
    return RedisCache.get(f"ride:{ride_id}")


def invalidate_ride_cache(ride_id: str):
    """Invalidate ride cache"""
    RedisCache.delete(f"ride:{ride_id}")
