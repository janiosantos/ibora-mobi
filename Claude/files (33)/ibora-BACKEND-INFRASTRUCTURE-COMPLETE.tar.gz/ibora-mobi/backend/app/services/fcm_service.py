"""
Firebase Cloud Messaging (FCM) Service
Push notifications for iOS and Android
"""
import firebase_admin
from firebase_admin import credentials, messaging
from typing import List, Dict, Optional
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)

# Initialize Firebase Admin SDK
try:
    cred = credentials.Certificate(settings.FIREBASE_CREDENTIALS_PATH)
    firebase_admin.initialize_app(cred)
    logger.info("Firebase initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize Firebase: {e}")


class FCMService:
    """Firebase Cloud Messaging service"""
    
    @staticmethod
    def send_notification(
        token: str,
        title: str,
        body: str,
        data: Optional[Dict] = None,
        badge: Optional[int] = None,
        sound: str = "default",
    ) -> bool:
        """
        Send push notification to single device
        
        Args:
            token: FCM device token
            title: Notification title
            body: Notification body
            data: Additional data payload
            badge: iOS badge count
            sound: Notification sound
            
        Returns:
            True if sent successfully
        """
        try:
            # Build notification
            notification = messaging.Notification(
                title=title,
                body=body,
            )
            
            # Build APNS config (iOS)
            apns = messaging.APNSConfig(
                headers={"apns-priority": "10"},
                payload=messaging.APNSPayload(
                    aps=messaging.Aps(
                        alert=messaging.ApsAlert(
                            title=title,
                            body=body,
                        ),
                        badge=badge,
                        sound=sound,
                        content_available=True,
                    )
                ),
            )
            
            # Build Android config
            android = messaging.AndroidConfig(
                priority="high",
                notification=messaging.AndroidNotification(
                    title=title,
                    body=body,
                    sound=sound,
                    channel_id="ibora_notifications",
                    priority="high",
                ),
            )
            
            # Build message
            message = messaging.Message(
                notification=notification,
                data=data or {},
                token=token,
                apns=apns,
                android=android,
            )
            
            # Send
            response = messaging.send(message)
            logger.info(f"Successfully sent notification: {response}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send notification: {e}")
            return False
    
    @staticmethod
    def send_multicast(
        tokens: List[str],
        title: str,
        body: str,
        data: Optional[Dict] = None,
    ) -> Dict:
        """
        Send notification to multiple devices
        
        Returns:
            {
                "success_count": int,
                "failure_count": int,
                "failed_tokens": List[str]
            }
        """
        try:
            # Build notification
            notification = messaging.Notification(
                title=title,
                body=body,
            )
            
            # Build message
            message = messaging.MulticastMessage(
                notification=notification,
                data=data or {},
                tokens=tokens,
            )
            
            # Send
            response = messaging.send_multicast(message)
            
            # Process failures
            failed_tokens = []
            if response.failure_count > 0:
                for idx, resp in enumerate(response.responses):
                    if not resp.success:
                        failed_tokens.append(tokens[idx])
                        logger.error(f"Failed to send to {tokens[idx]}: {resp.exception}")
            
            return {
                "success_count": response.success_count,
                "failure_count": response.failure_count,
                "failed_tokens": failed_tokens,
            }
            
        except Exception as e:
            logger.error(f"Failed to send multicast: {e}")
            return {
                "success_count": 0,
                "failure_count": len(tokens),
                "failed_tokens": tokens,
            }
    
    @staticmethod
    def send_topic(
        topic: str,
        title: str,
        body: str,
        data: Optional[Dict] = None,
    ) -> bool:
        """
        Send notification to topic subscribers
        
        Topics:
            - drivers: All drivers
            - passengers: All passengers
            - zone:sp: Drivers in São Paulo
        """
        try:
            message = messaging.Message(
                notification=messaging.Notification(
                    title=title,
                    body=body,
                ),
                data=data or {},
                topic=topic,
            )
            
            response = messaging.send(message)
            logger.info(f"Sent to topic {topic}: {response}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send to topic {topic}: {e}")
            return False
    
    @staticmethod
    def subscribe_to_topic(token: str, topic: str) -> bool:
        """Subscribe device to topic"""
        try:
            messaging.subscribe_to_topic([token], topic)
            return True
        except Exception as e:
            logger.error(f"Failed to subscribe to topic: {e}")
            return False
    
    @staticmethod
    def unsubscribe_from_topic(token: str, topic: str) -> bool:
        """Unsubscribe device from topic"""
        try:
            messaging.unsubscribe_from_topic([token], topic)
            return True
        except Exception as e:
            logger.error(f"Failed to unsubscribe from topic: {e}")
            return False


# Notification templates
class NotificationTemplates:
    """Pre-defined notification templates"""
    
    @staticmethod
    def ride_request(passenger_name: str, pickup_address: str) -> Dict:
        """Notification when driver receives ride request"""
        return {
            "title": "🚗 Nova Solicitação de Corrida",
            "body": f"{passenger_name} solicitou uma corrida em {pickup_address}",
            "data": {
                "type": "RIDE_REQUEST",
                "sound": "ride_request.wav",
            }
        }
    
    @staticmethod
    def driver_assigned(driver_name: str, eta: int) -> Dict:
        """Notification when driver accepts ride"""
        return {
            "title": "✅ Motorista a Caminho",
            "body": f"{driver_name} aceitou sua corrida. Chegará em ~{eta} min",
            "data": {
                "type": "DRIVER_ASSIGNED",
            }
        }
    
    @staticmethod
    def driver_arrived() -> Dict:
        """Notification when driver arrives"""
        return {
            "title": "📍 Motorista Chegou",
            "body": "Seu motorista chegou no local de embarque",
            "data": {
                "type": "DRIVER_ARRIVED",
                "sound": "arrived.wav",
            }
        }
    
    @staticmethod
    def ride_started() -> Dict:
        """Notification when ride starts"""
        return {
            "title": "🚀 Corrida Iniciada",
            "body": "Sua corrida começou. Tenha uma boa viagem!",
            "data": {
                "type": "RIDE_STARTED",
            }
        }
    
    @staticmethod
    def ride_completed(price: float) -> Dict:
        """Notification when ride completes"""
        return {
            "title": "🎯 Corrida Finalizada",
            "body": f"Corrida concluída. Valor: R$ {price:.2f}",
            "data": {
                "type": "RIDE_COMPLETED",
            }
        }
    
    @staticmethod
    def payment_received(amount: float) -> Dict:
        """Notification when payment is received"""
        return {
            "title": "💰 Pagamento Recebido",
            "body": f"Pagamento de R$ {amount:.2f} confirmado",
            "data": {
                "type": "PAYMENT_RECEIVED",
            }
        }
    
    @staticmethod
    def withdrawal_approved(amount: float) -> Dict:
        """Notification when withdrawal is approved"""
        return {
            "title": "💸 Saque Aprovado",
            "body": f"Saque de R$ {amount:.2f} processado com sucesso",
            "data": {
                "type": "WITHDRAWAL_APPROVED",
            }
        }
    
    @staticmethod
    def ride_cancelled(cancelled_by: str) -> Dict:
        """Notification when ride is cancelled"""
        return {
            "title": "❌ Corrida Cancelada",
            "body": f"Corrida cancelada por {cancelled_by}",
            "data": {
                "type": "RIDE_CANCELLED",
            }
        }
    
    @staticmethod
    def chat_message(sender: str, message: str) -> Dict:
        """Notification for new chat message"""
        return {
            "title": f"💬 {sender}",
            "body": message[:100],
            "data": {
                "type": "CHAT_MESSAGE",
            }
        }


# Helper functions
def send_ride_request_notification(driver_token: str, passenger_name: str, pickup: str):
    """Send ride request notification to driver"""
    template = NotificationTemplates.ride_request(passenger_name, pickup)
    FCMService.send_notification(
        token=driver_token,
        title=template["title"],
        body=template["body"],
        data=template["data"],
        badge=1,
    )


def send_driver_assigned_notification(passenger_token: str, driver_name: str, eta: int):
    """Send driver assigned notification to passenger"""
    template = NotificationTemplates.driver_assigned(driver_name, eta)
    FCMService.send_notification(
        token=passenger_token,
        title=template["title"],
        body=template["body"],
        data=template["data"],
    )
