"""
Celery Configuration
Background tasks with Redis broker and RabbitMQ backend
"""
from celery import Celery
from celery.schedules import crontab
from app.core.config import settings

# Initialize Celery
celery_app = Celery(
    "ibora",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=[
        "app.tasks.settlement",
        "app.tasks.notifications",
        "app.tasks.matching",
        "app.tasks.cleanup",
    ]
)

# Celery configuration
celery_app.conf.update(
    # Task settings
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="America/Sao_Paulo",
    enable_utc=True,
    
    # Result backend settings
    result_expires=3600,  # 1 hour
    result_backend_transport_options={
        "master_name": "mymaster",
        "visibility_timeout": 3600,
    },
    
    # Worker settings
    worker_prefetch_multiplier=4,
    worker_max_tasks_per_child=1000,
    worker_disable_rate_limits=False,
    
    # Task execution
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    task_time_limit=300,  # 5 minutes
    task_soft_time_limit=240,  # 4 minutes
    
    # Retry settings
    task_default_retry_delay=60,  # 1 minute
    task_max_retries=3,
    
    # Rate limiting
    task_default_rate_limit="100/m",
    
    # Redis connection pool
    broker_pool_limit=10,
    broker_connection_retry_on_startup=True,
    
    # Task routes
    task_routes={
        "app.tasks.settlement.*": {"queue": "settlement"},
        "app.tasks.notifications.*": {"queue": "notifications"},
        "app.tasks.matching.*": {"queue": "matching"},
        "app.tasks.cleanup.*": {"queue": "cleanup"},
    },
    
    # Beat schedule (periodic tasks)
    beat_schedule={
        # Settlement D+N (daily at 2 AM)
        "settlement-daily": {
            "task": "app.tasks.settlement.run_daily_settlement",
            "schedule": crontab(hour=2, minute=0),
            "options": {"queue": "settlement"},
        },
        
        # Cleanup old rides (daily at 3 AM)
        "cleanup-old-rides": {
            "task": "app.tasks.cleanup.cleanup_old_rides",
            "schedule": crontab(hour=3, minute=0),
            "options": {"queue": "cleanup"},
        },
        
        # Cleanup expired notifications (every hour)
        "cleanup-notifications": {
            "task": "app.tasks.cleanup.cleanup_old_notifications",
            "schedule": crontab(minute=0),  # Every hour
            "options": {"queue": "cleanup"},
        },
        
        # Update driver metrics (every 5 minutes)
        "update-driver-metrics": {
            "task": "app.tasks.matching.update_driver_metrics",
            "schedule": crontab(minute="*/5"),
            "options": {"queue": "matching"},
        },
        
        # Check pending PIX payments (every 2 minutes)
        "check-pix-payments": {
            "task": "app.tasks.notifications.check_pending_pix",
            "schedule": crontab(minute="*/2"),
            "options": {"queue": "notifications"},
        },
    },
)

# Task annotations
celery_app.conf.task_annotations = {
    "*": {
        "rate_limit": "100/m",
    },
    "app.tasks.notifications.send_push_notification": {
        "rate_limit": "1000/m",
        "time_limit": 30,
    },
    "app.tasks.settlement.run_daily_settlement": {
        "time_limit": 600,  # 10 minutes
        "soft_time_limit": 540,
    },
}

# Error handling
celery_app.conf.task_send_sent_event = True
celery_app.conf.task_track_started = True

if __name__ == "__main__":
    celery_app.start()
