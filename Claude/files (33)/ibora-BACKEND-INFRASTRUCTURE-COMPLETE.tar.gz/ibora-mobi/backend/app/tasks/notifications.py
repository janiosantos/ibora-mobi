"""
Notification Tasks
Push notifications via FCM
"""
from celery import Task
from app.celery_app import celery_app
from app.db.session import SessionLocal
from app.services.fcm_service import FCMService, NotificationTemplates
from app.services.payment_service import PaymentService
from app.core.redis import RateLimiter
import logging

logger = logging.getLogger(__name__)


@celery_app.task(
    name="app.tasks.notifications.send_push_notification",
    max_retries=3,
    default_retry_delay=30,
)
def send_push_notification(
    token: str,
    title: str,
    body: str,
    data: dict = None,
    user_id: str = None,
):
    """
    Send push notification
    
    Rate limited to 1000/minute per user
    """
    try:
        # Rate limit per user
        if user_id:
            limiter = RateLimiter(f"push:{user_id}", limit=60, window=60)
            if not limiter.is_allowed():
                logger.warning(f"Rate limit exceeded for user {user_id}")
                return {"status": "rate_limited"}
        
        # Send notification
        success = FCMService.send_notification(
            token=token,
            title=title,
            body=body,
            data=data or {},
        )
        
        return {
            "status": "success" if success else "failed",
            "token": token[:10] + "...",
        }
        
    except Exception as e:
        logger.error(f"Failed to send notification: {e}")
        return {"status": "error", "message": str(e)}


@celery_app.task(name="app.tasks.notifications.send_ride_request")
def send_ride_request(
    driver_token: str,
    passenger_name: str,
    pickup_address: str,
    ride_id: str,
):
    """Send ride request notification to driver"""
    template = NotificationTemplates.ride_request(passenger_name, pickup_address)
    
    return send_push_notification(
        token=driver_token,
        title=template["title"],
        body=template["body"],
        data={
            **template["data"],
            "ride_id": ride_id,
        }
    )


@celery_app.task(name="app.tasks.notifications.send_driver_assigned")
def send_driver_assigned(
    passenger_token: str,
    driver_name: str,
    eta: int,
    ride_id: str,
):
    """Send driver assigned notification"""
    template = NotificationTemplates.driver_assigned(driver_name, eta)
    
    return send_push_notification(
        token=passenger_token,
        title=template["title"],
        body=template["body"],
        data={
            **template["data"],
            "ride_id": ride_id,
        }
    )


@celery_app.task(name="app.tasks.notifications.send_driver_arrived")
def send_driver_arrived(passenger_token: str, ride_id: str):
    """Send driver arrived notification"""
    template = NotificationTemplates.driver_arrived()
    
    return send_push_notification(
        token=passenger_token,
        title=template["title"],
        body=template["body"],
        data={
            **template["data"],
            "ride_id": ride_id,
        }
    )


@celery_app.task(name="app.tasks.notifications.send_ride_completed")
def send_ride_completed(
    passenger_token: str,
    driver_token: str,
    price: float,
    ride_id: str,
):
    """Send ride completed notification to both"""
    template = NotificationTemplates.ride_completed(price)
    
    # Send to passenger
    send_push_notification(
        token=passenger_token,
        title=template["title"],
        body=template["body"],
        data={
            **template["data"],
            "ride_id": ride_id,
        }
    )
    
    # Send to driver (different message)
    send_push_notification(
        token=driver_token,
        title="✅ Corrida Finalizada",
        body=f"Você ganhou R$ {price * 0.8:.2f}",
        data={
            "type": "RIDE_COMPLETED",
            "ride_id": ride_id,
        }
    )


@celery_app.task(name="app.tasks.notifications.send_payment_received")
def send_payment_received(driver_token: str, amount: float):
    """Send payment received notification"""
    template = NotificationTemplates.payment_received(amount)
    
    return send_push_notification(
        token=driver_token,
        title=template["title"],
        body=template["body"],
        data=template["data"]
    )


@celery_app.task(name="app.tasks.notifications.check_pending_pix")
def check_pending_pix():
    """
    Check pending PIX payments
    Runs every 2 minutes
    """
    with SessionLocal() as db:
        from app.models.ride import Ride
        from sqlalchemy import select, and_
        
        try:
            # Get rides with pending PIX payments
            result = db.execute(
                select(Ride).where(
                    and_(
                        Ride.payment_method == "pix",
                        Ride.payment_status == "pending"
                    )
                )
            )
            rides = result.scalars().all()
            
            checked = 0
            paid = 0
            
            for ride in rides:
                if ride.payment_id:
                    # Check status
                    import asyncio
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    
                    status = loop.run_until_complete(
                        PaymentService.check_pix_status(ride.payment_id)
                    )
                    
                    checked += 1
                    
                    if status == "PAID":
                        # Update ride
                        ride.payment_status = "paid"
                        
                        # Process wallet
                        from app.services.wallet_service import WalletService
                        loop.run_until_complete(
                            WalletService.process_ride_payment(
                                db=db,
                                ride=ride,
                                payment_id=ride.payment_id
                            )
                        )
                        
                        # Send notification
                        if ride.driver and ride.driver.fcm_token:
                            send_payment_received.delay(
                                ride.driver.fcm_token,
                                ride.driver_earnings
                            )
                        
                        paid += 1
            
            db.commit()
            
            return {
                "status": "success",
                "checked": checked,
                "paid": paid,
            }
            
        except Exception as e:
            logger.error(f"Error checking PIX payments: {e}")
            return {"status": "error", "message": str(e)}


@celery_app.task(name="app.tasks.notifications.broadcast_to_topic")
def broadcast_to_topic(topic: str, title: str, body: str, data: dict = None):
    """
    Broadcast notification to topic
    
    Topics:
        - drivers: All drivers
        - passengers: All passengers
        - zone:sp: Zone-specific
    """
    try:
        success = FCMService.send_topic(
            topic=topic,
            title=title,
            body=body,
            data=data or {},
        )
        
        return {
            "status": "success" if success else "failed",
            "topic": topic,
        }
        
    except Exception as e:
        logger.error(f"Failed to broadcast to topic {topic}: {e}")
        return {"status": "error", "message": str(e)}
