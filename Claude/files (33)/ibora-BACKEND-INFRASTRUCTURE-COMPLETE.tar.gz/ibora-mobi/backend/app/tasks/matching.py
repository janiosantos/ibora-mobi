"""
Matching and Cleanup Tasks
"""
from celery import Task
from app.celery_app import celery_app
from app.db.session import SessionLocal
from app.core.redis import RedisCache, RedisLock
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


# ==================== MATCHING TASKS ====================

@celery_app.task(name="app.tasks.matching.update_driver_metrics")
def update_driver_metrics():
    """
    Update driver metrics cache
    Runs every 5 minutes
    """
    with SessionLocal() as db:
        from app.models.user import User, UserRole
        from sqlalchemy import select, and_
        
        try:
            # Get online drivers
            result = db.execute(
                select(User).where(
                    and_(
                        User.role == UserRole.DRIVER,
                        User.online == True,
                        User.deleted_at.is_(None)
                    )
                )
            )
            drivers = result.scalars().all()
            
            updated = 0
            
            for driver in drivers:
                # Cache driver metrics
                metrics = {
                    "driver_id": str(driver.id),
                    "online": driver.online,
                    "rating": driver.rating,
                    "rides_count": driver.rides_count or 0,
                    "last_location": {
                        "lat": driver.last_lat,
                        "lng": driver.last_lng,
                    } if driver.last_lat and driver.last_lng else None,
                    "last_update": str(driver.last_location_update) if driver.last_location_update else None,
                }
                
                RedisCache.set(
                    f"driver:{driver.id}:metrics",
                    metrics,
                    ttl=600  # 10 min
                )
                
                updated += 1
            
            logger.info(f"Updated metrics for {updated} drivers")
            
            return {
                "status": "success",
                "updated": updated,
            }
            
        except Exception as e:
            logger.error(f"Error updating driver metrics: {e}")
            return {"status": "error", "message": str(e)}


@celery_app.task(name="app.tasks.matching.find_drivers_for_ride")
def find_drivers_for_ride(ride_id: str, pickup_lat: float, pickup_lng: float):
    """
    Find available drivers near pickup
    Background task for ride matching
    """
    with SessionLocal() as db:
        from app.services.ride_service import RideService
        
        try:
            # Use lock to prevent duplicate searches
            with RedisLock(f"matching:ride:{ride_id}", timeout=30):
                import asyncio
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                # Find drivers
                drivers = loop.run_until_complete(
                    RideService.find_available_drivers(
                        db=db,
                        pickup_lat=pickup_lat,
                        pickup_lng=pickup_lng,
                        max_distance_km=5.0
                    )
                )
                
                # Cache results
                driver_ids = [str(d.id) for d in drivers]
                RedisCache.set(
                    f"ride:{ride_id}:available_drivers",
                    driver_ids,
                    ttl=300  # 5 min
                )
                
                logger.info(f"Found {len(drivers)} drivers for ride {ride_id}")
                
                return {
                    "status": "success",
                    "ride_id": ride_id,
                    "drivers_found": len(drivers),
                    "driver_ids": driver_ids,
                }
                
        except Exception as e:
            logger.error(f"Error finding drivers for ride {ride_id}: {e}")
            return {"status": "error", "message": str(e)}


# ==================== CLEANUP TASKS ====================

@celery_app.task(name="app.tasks.cleanup.cleanup_old_rides")
def cleanup_old_rides():
    """
    Cleanup old rides
    Runs daily at 3 AM
    """
    with SessionLocal() as db:
        from app.models.ride import Ride, RideStatus
        from sqlalchemy import select, and_
        
        try:
            # Delete rides older than 90 days
            cutoff_date = datetime.utcnow() - timedelta(days=90)
            
            result = db.execute(
                select(Ride).where(
                    and_(
                        Ride.created_at < cutoff_date,
                        Ride.status.in_([
                            RideStatus.CANCELLED_BY_DRIVER,
                            RideStatus.CANCELLED_BY_PASSENGER,
                            RideStatus.COMPLETED
                        ])
                    )
                )
            )
            rides = result.scalars().all()
            
            deleted = 0
            
            for ride in rides:
                ride.deleted_at = datetime.utcnow()
                deleted += 1
            
            db.commit()
            
            logger.info(f"Cleaned up {deleted} old rides")
            
            return {
                "status": "success",
                "deleted": deleted,
            }
            
        except Exception as e:
            logger.error(f"Error cleaning up rides: {e}")
            db.rollback()
            return {"status": "error", "message": str(e)}


@celery_app.task(name="app.tasks.cleanup.cleanup_old_notifications")
def cleanup_old_notifications():
    """
    Cleanup old notification records
    Runs every hour
    """
    try:
        # Delete notification cache older than 24h
        pattern = "notification:*"
        keys = RedisCache.get_pattern(pattern)
        
        deleted = 0
        for key in keys:
            # Check if expired (simple check)
            if not RedisCache.exists(key):
                continue
            
            # Delete old notifications (implement your logic)
            # For now, just count
            deleted += 1
        
        logger.info(f"Checked {len(keys)} notification keys")
        
        return {
            "status": "success",
            "checked": len(keys),
        }
        
    except Exception as e:
        logger.error(f"Error cleaning up notifications: {e}")
        return {"status": "error", "message": str(e)}


@celery_app.task(name="app.tasks.cleanup.cleanup_expired_locks")
def cleanup_expired_locks():
    """
    Cleanup expired Redis locks
    Runs every hour
    """
    try:
        pattern = "lock:*"
        keys = RedisCache.get_pattern(pattern)
        
        # Locks expire automatically, just count them
        logger.info(f"Found {len(keys)} active locks")
        
        return {
            "status": "success",
            "active_locks": len(keys),
        }
        
    except Exception as e:
        logger.error(f"Error checking locks: {e}")
        return {"status": "error", "message": str(e)}


@celery_app.task(name="app.tasks.cleanup.cleanup_stale_drivers")
def cleanup_stale_drivers():
    """
    Mark drivers as offline if no location update in 10 minutes
    """
    with SessionLocal() as db:
        from app.models.user import User, UserRole
        from sqlalchemy import select, and_
        
        try:
            cutoff = datetime.utcnow() - timedelta(minutes=10)
            
            # Get online drivers with stale location
            result = db.execute(
                select(User).where(
                    and_(
                        User.role == UserRole.DRIVER,
                        User.online == True,
                        User.last_location_update < cutoff
                    )
                )
            )
            drivers = result.scalars().all()
            
            updated = 0
            
            for driver in drivers:
                driver.online = False
                updated += 1
            
            db.commit()
            
            logger.info(f"Marked {updated} drivers as offline")
            
            return {
                "status": "success",
                "updated": updated,
            }
            
        except Exception as e:
            logger.error(f"Error cleaning stale drivers: {e}")
            db.rollback()
            return {"status": "error", "message": str(e)}
