"""
Settlement Tasks
Daily D+N settlement of driver earnings
"""
from celery import Task
from app.celery_app import celery_app
from app.db.session import SessionLocal
from app.services.wallet_service import WalletService
from app.core.redis import RedisLock, RedisCache
import logging

logger = logging.getLogger(__name__)


class SettlementTask(Task):
    """Base task with DB session"""
    
    def __call__(self, *args, **kwargs):
        with SessionLocal() as db:
            return self.run(db, *args, **kwargs)


@celery_app.task(
    bind=True,
    base=SettlementTask,
    name="app.tasks.settlement.run_daily_settlement",
    max_retries=3,
    default_retry_delay=300,  # 5 minutes
)
def run_daily_settlement(self, db):
    """
    Daily settlement job (D+N)
    
    Moves pending balance to available after settlement date
    Runs at 2 AM daily
    """
    # Use distributed lock to prevent duplicate runs
    lock_key = "settlement:daily"
    
    try:
        with RedisLock(lock_key, timeout=600):  # 10 min lock
            logger.info("Starting daily settlement...")
            
            # Run settlement
            import asyncio
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            settled_count = loop.run_until_complete(
                WalletService.settle_pending_events(db)
            )
            
            logger.info(f"Settlement complete: {settled_count} events settled")
            
            # Cache result
            RedisCache.set(
                "settlement:last_run",
                {
                    "count": settled_count,
                    "timestamp": str(asyncio.get_event_loop().time()),
                },
                ttl=86400,  # 24 hours
            )
            
            return {
                "status": "success",
                "settled_count": settled_count,
            }
            
    except Exception as exc:
        logger.error(f"Settlement failed: {exc}")
        raise self.retry(exc=exc)


@celery_app.task(name="app.tasks.settlement.settle_single_driver")
def settle_single_driver(driver_id: str):
    """
    Settle single driver (manual trigger)
    """
    with SessionLocal() as db:
        try:
            from app.models.user import User
            from sqlalchemy import select
            
            # Get driver
            result = db.execute(
                select(User).where(User.id == driver_id)
            )
            driver = result.scalar_one_or_none()
            
            if not driver:
                return {"status": "error", "message": "Driver not found"}
            
            # Get wallet
            import asyncio
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            wallet = loop.run_until_complete(
                WalletService.get_or_create_wallet(db, driver.id, "driver")
            )
            
            # Settle
            settled = loop.run_until_complete(
                WalletService.settle_pending_events(db)
            )
            
            return {
                "status": "success",
                "driver_id": driver_id,
                "settled_count": settled,
            }
            
        except Exception as e:
            logger.error(f"Failed to settle driver {driver_id}: {e}")
            return {"status": "error", "message": str(e)}


@celery_app.task(name="app.tasks.settlement.check_settlement_status")
def check_settlement_status():
    """
    Check settlement status
    Returns last run info
    """
    last_run = RedisCache.get("settlement:last_run")
    
    if not last_run:
        return {
            "status": "never_run",
            "message": "Settlement has never run",
        }
    
    return {
        "status": "success",
        "last_run": last_run,
    }
