CREATE INDEX accounts_parents ON accounts(parent_account_id);
