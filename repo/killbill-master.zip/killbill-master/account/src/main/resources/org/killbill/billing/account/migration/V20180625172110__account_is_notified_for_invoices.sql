alter table accounts drop column is_notified_for_invoices;
alter table account_history drop column is_notified_for_invoices;
