# Spree Admin Dashboard

Welcome to the Spree Admin Dashboard repository. This is a new, shiny admin dashboard for Spree Commerce 5.

## Installation

To install the Spree Admin Dashboard, run the following command:

```bash
bundle add spree_admin
```

Run the install generator:

```bash
bin/rails g spree:admin:install
```

This will create the necessary files for the admin dashboard.

You will need to restart your web server and run `bin/dev` to start the development server for the admin dashboard.