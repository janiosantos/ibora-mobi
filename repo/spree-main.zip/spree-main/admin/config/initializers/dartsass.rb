Rails.application.config.dartsass.builds = {
  Spree::Admin::Engine.root.join('app/assets/stylesheets/spree/admin/application.scss') => 'spree/admin/application.css'
}
