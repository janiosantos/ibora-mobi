Chartkick.options = {
  colors: ["#0090FE"],
  zeros: true,
  points: false
}
