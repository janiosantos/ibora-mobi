import { Socket } from "./socket.js";

export default (uri, opts) => new Socket(uri, opts);
