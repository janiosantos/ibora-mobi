<template>
  <div>
    <Connection />
  </div>
</template>
