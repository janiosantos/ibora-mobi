
# Example with [ES modules](https://nodejs.org/api/esm.html)

## How to use

```
# install the dependencies
$ npm ci

# start the server
$ node server.js

# start the client
$ node client.js
```

You need Node.js `>=12.17.0`.
