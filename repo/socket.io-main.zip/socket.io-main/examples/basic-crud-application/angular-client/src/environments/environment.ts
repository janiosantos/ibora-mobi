export const environment = {
  serverUrl: "https://my-custom-domain.com"
};
