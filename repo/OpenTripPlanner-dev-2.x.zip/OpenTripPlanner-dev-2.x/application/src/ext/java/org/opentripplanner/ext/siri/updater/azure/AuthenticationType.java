package org.opentripplanner.ext.siri.updater.azure;

public enum AuthenticationType {
  SharedAccessKey,
  FederatedIdentity,
}
