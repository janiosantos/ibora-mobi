# Google cloud storage integration

Add support for Google Cloud Storage, getting all input files and storing the graph.obj in the
cloud.

This implementation will use the existing OtpConfigLoader to load config from the local disk.
