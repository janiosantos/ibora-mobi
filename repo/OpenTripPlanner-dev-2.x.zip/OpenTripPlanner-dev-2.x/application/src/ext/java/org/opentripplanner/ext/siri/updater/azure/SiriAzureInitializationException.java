package org.opentripplanner.ext.siri.updater.azure;

public class SiriAzureInitializationException extends RuntimeException {

  public SiriAzureInitializationException(String message, Throwable cause) {
    super(message, cause);
  }
}
