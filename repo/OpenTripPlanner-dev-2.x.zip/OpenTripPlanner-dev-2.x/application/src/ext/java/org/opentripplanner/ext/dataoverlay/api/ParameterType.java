package org.opentripplanner.ext.dataoverlay.api;

/**
 * @see ParameterName
 */
public enum ParameterType {
  THRESHOLD,
  PENALTY,
}
