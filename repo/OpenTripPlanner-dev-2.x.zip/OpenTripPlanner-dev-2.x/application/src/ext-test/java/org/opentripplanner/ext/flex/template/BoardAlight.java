package org.opentripplanner.ext.flex.template;

enum BoardAlight {
  BOARD_ONLY,
  ALIGHT_ONLY,
  BOARD_AND_ALIGHT,
}
